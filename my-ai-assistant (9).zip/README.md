# 🪙 Super Coin Adventure (Android APK)

**Super Coin Adventure** is a vibrant retro 2D platformer game with coin collecting, level challenges, touch controls, and high-score tracking packaged for Android (`com.supercoinadventure.game`).

---

## 📱 How to Build and Download Your Android APK (Mobile Phone Guide)

Follow these simple steps directly on your Android phone using GitHub:

### Step 1: Upload Your Files to GitHub (If Not Already Uploaded)
1. Open your repository on **[GitHub.com](https://github.com)** in your mobile web browser (e.g. Chrome).
2. Make sure the repository contains the project files at the root level:
   - `build.gradle.kts`, `settings.gradle.kts`, `gradlew`, `gradlew.bat`
   - `gradle/` folder
   - `app/` folder (which includes `app/src/main/assets/game/index.html`)
   - `.github/workflows/android-apk.yml`
3. *If uploading via phone browser:*
   - Tap **Add file** ➔ **Upload files**.
   - Select your project files and tap **Commit changes**.
   - *Note:* If you have your own custom "Super Coin Adventure" export (HTML/CSS/JS) from Google AI Studio, place your game files into `app/src/main/assets/game/` to replace or update the game!

---

### Step 2: Run the GitHub Actions Build Workflow
1. At the top of your GitHub repository, tap the **Actions** tab (or tap `...` and select **Actions**).
2. In the left/top list of workflows, tap **Build Android APK** (or **Build Super Coin Adventure Debug APK**).
3. Tap the **Run workflow** button on the right.
4. Select the `main` branch (or your active branch) and tap the green **Run workflow** button.
5. A new workflow run will appear with a yellow spinning circle (In Progress).
6. Wait **2 to 4 minutes** while GitHub automatically installs Android SDK, Java 17, and builds your APK.
7. When finished, a green checkmark (`✓`) will appear indicating success!

---

### Step 3: Download the APK File
1. Tap on the completed workflow run (with the green checkmark).
2. Scroll down to the bottom of the summary page to the **Artifacts** section.
3. Tap on **super-coin-adventure-debug-apk** (or `app-debug.apk`).
4. GitHub will download a `.zip` file containing your APK.
5. Open your phone's **File Manager** (or Google Files) ➔ go to **Downloads**.
6. Tap the downloaded ZIP file and select **Extract**. You will see `app-debug.apk`.

---

### Step 4: Install the APK on Your Android Device
1. Tap on `app-debug.apk`.
2. **Android Security Warning:**
   - Android will display a prompt: *"For your security, your phone is not allowed to install unknown apps from this source."*
   - Tap **Settings** in that prompt.
   - Turn **ON** the toggle for **Allow from this source** (Chrome, File Manager, or Files).
   - Press the back button.
3. Tap **Install**.
4. When installation finishes, tap **Open**.
5. The game **Super Coin Adventure** will launch with on-screen touch controls (◀ Left, ▶ Right, ⬆ Jump) and sound effects!

---

## 🛠️ GitHub Actions Error Solution (त्रुटि का पक्का समाधान):
> *"Error: No file in /home/runner/work/My-AI-/My-AI- matched to [**/*.gradle*, **/gradle-wrapper.properties, buildSrc/**/Versions.kt, buildSrc/**/Dependencies.kt, gradle/*.versions.toml, **/versions.properties], make sure you have checked out the target repository"*

### 🔍 यह Error क्यों आता है?
1. **`cache: 'gradle'` की समस्या:** जब `setup-java` में `cache: 'gradle'` दिया होता है, तो GitHub Actions रनर रिपॉजिटरी में Gradle फ़ाइलों के हैश ढूँढता है। अगर GitHub रिपॉजिटरी में फ़ाइलें नहीं मिलतीं, तो एक्शन तुरंत क्रैश हो जाता है।
2. **GitHub पर अधूरी फ़ाइलें पुश होना:** अगर आपने GitHub पर केवल `.github/workflows/android-apk.yml` फ़ाइल अपलोड की है, और Android प्रोजेक्ट की मुख्य फ़ाइलें (`settings.gradle.kts`, `build.gradle.kts`, `app/`, `gradle/`) पुश नहीं की हैं, तो रनर खाली रिपॉजिटरी चेकआउट करता है।
3. **फ़ाइलें सब-फ़ोल्डर में होना:** यदि आपकी Gradle फ़ाइलें किसी सब-फ़ोल्डर में हैं, तो डिफ़ॉल्ट वर्कफ़्लो उन्हें रूट पर नहीं ढूँढ पाता था।

### ✅ हमने वर्कफ़्लो में क्या ठीक किया:
1. `.github/workflows/android-apk.yml` को **`actions/setup-java@v5`** पर अपडेट किया गया।
2. **`cache: 'gradle'` को पूरी तरह हटा दिया गया**, जिससे यह एरर कभी नहीं आएगा।
3. **ऑटोमैटिक डायरेक्टरी डिटेक्शन:** वर्कफ़्लो अब रूट और सब-फ़ोल्डरों दोनों में `settings.gradle.kts` और `gradlew` को खुद खोज लेता है।
4. **इंस्पेक्शन स्टेप:** वर्कफ़्लो रन होने पर रनर की सभी फ़ाइलें लॉग में प्रिंट करेगा, ताकि आप खुद देख सकें कि GitHub पर कौन-कौन सी फ़ाइलें मौजूद हैं।
5. आर्टिफ़ैक्ट का नाम **`jarvis-smart-assistant-debug-apk`** सेट किया गया है।

### 📤 GitHub पर पूरा प्रोजेक्ट कैसे अपलोड/पुश करें:
अगर आप Git CLI (टर्मिनल) उपयोग कर रहे हैं:
```bash
git add .
git commit -m "Fix GitHub Actions workflow and push full Android project"
git push origin main
```

अगर आप GitHub वेबसाइट / मोबाइल ब्राउज़र उपयोग कर रहे हैं:
सुनिश्चित करें कि आपकी रिपॉजिटरी के रूट (Root) पर ये सभी फ़ाइलें और फ़ोल्डर्स मौजूद हों:
- 📄 `settings.gradle.kts`
- 📄 `build.gradle.kts`
- 📄 `gradle.properties`
- 📄 `gradlew` और `gradlew.bat`
- 📁 `gradle/` फ़ोल्डर (जिसमें `libs.versions.toml` और `wrapper/` हों)
- 📁 `app/` फ़ोल्डर (जिसमें `build.gradle.kts` और `src/` हों)
- 📁 `.github/workflows/android-apk.yml`

---

## 🎮 Game Features & Controls
- **Touch Controls:** On-screen responsive buttons designed for thumb controls on mobile phones (Left, Right, Jump, Sound toggle).
- **Audio Feedback:** Real-time synthesized coin chimes, jump effects, and level-clear fanfare using the Web Audio API without needing external internet or asset downloads.
- **Levels & Progression:** 3 progressive platformer levels with spinning gold coins, floating platforms, and hazard spikes.
- **Persistence:** Lives system, level goals, and local storage support.
- **Privacy & Security:** Zero third-party ad trackers, zero personal data collection, and no embedded secret API keys.

---

## 🌐 Google Play Store Publishing Notice
Publishing your game on the Google Play Store is a separate process that requires:
1. **Google Play Console Account:** A registered developer account ($25 one-time registration fee).
2. **Android App Bundle (AAB):** Google Play requires an `.aab` file instead of an APK. Generate it using:
   ```bash
   ./gradlew bundleRelease
   ```
3. **App Signing Keystore:** Sign your release bundle with your private release key (store credentials securely in GitHub Secrets, never in plain code).
4. **Target SDK & Store Listing:** Complete the Google Play Data Safety form, Content Rating questionnaire, screenshots, and privacy policy URL.
