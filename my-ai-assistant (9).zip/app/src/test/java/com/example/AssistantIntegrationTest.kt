package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.actions.ActionType
import com.example.actions.IntentParser
import com.example.actions.SmartActionExecutor
import com.example.data.preferences.AssistantPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AssistantIntegrationTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun testYouTubeAppCommandInterpretation() {
        val action = IntentParser.parse("YouTube kholo")
        assertEquals(ActionType.OPEN_APP, action.type)
        assertEquals("YouTube", action.parameters["appName"])
        assertFalse(action.requiresConfirmation)
    }

    @Test
    fun testYouTubeSongSearchCommandInterpretation() {
        val action = IntentParser.parse("YouTube par Arijit Singh ka gaana chalao")
        assertEquals(ActionType.SEARCH_YOUTUBE, action.type)
        assertTrue(action.parameters["query"]!!.contains("Arijit Singh", ignoreCase = true))
    }

    @Test
    fun testWhatsAppDraftingRequiresConfirmation() {
        val action = IntentParser.parse("WhatsApp par message bhejne ke liye taiyar karo: Kal milte hain")
        assertEquals(ActionType.PREPARE_MESSAGE, action.type)
        assertTrue(action.requiresConfirmation)
        assertNotNull(action.parameters["message"])
    }

    @Test
    fun testCameraAndSettingsCommandInterpretation() {
        val cameraAction = IntentParser.parse("Camera kholo")
        assertEquals(ActionType.OPEN_CAMERA, cameraAction.type)

        val settingsAction = IntentParser.parse("Phone ki settings kholo")
        assertEquals(ActionType.OPEN_SETTINGS, settingsAction.type)
    }

    @Test
    fun testInstalledAppsCommandInterpretation() {
        val action = IntentParser.parse("Mere installed apps dikhao")
        assertEquals(ActionType.SHOW_INSTALLED_APPS, action.type)
    }

    @Test
    fun testImageGeneratorCommandInterpretation() {
        val action = IntentParser.parse("Ek cinematic image banao jismein sunset ke samay pahadon ke beech ek futuristic city ho")
        assertEquals(ActionType.GENERATE_IMAGE, action.type)
        assertTrue(action.parameters["prompt"]!!.contains("futuristic city", ignoreCase = true))
    }

    @Test
    fun testVoiceStudioCommandInterpretation() {
        val action = IntentParser.parse("Voice change karo")
        assertEquals(ActionType.CHANGE_ASSISTANT_VOICE, action.type)
    }

    @Test
    fun testGeneralQuestionFallback() {
        val action = IntentParser.parse("Tum kaun ho?")
        assertEquals(ActionType.ANSWER_QUESTION, action.type)
    }

    @Test
    fun testPersistentPreferences() {
        val prefs = AssistantPreferences(context)
        prefs.language = "hi_IN"
        assertEquals("hi_IN", prefs.language)

        prefs.speechRate = 1.2f
        assertEquals(1.2f, prefs.speechRate, 0.01f)

        prefs.speechPitch = 1.1f
        assertEquals(1.1f, prefs.speechPitch, 0.01f)

        prefs.voiceName = "Hindi Voice 1"
        assertEquals("Hindi Voice 1", prefs.voiceName)
    }

    @Test
    fun testMissingAppGracefulHandling() {
        val result = SmartActionExecutor.launchApp(context, "com.nonexistent.fakepackage.app", "FakeApp")
        // Should return Failure instead of crashing
        assertTrue(result is com.example.actions.ExecutionResult.Failure)
    }

    @Test
    fun testEmergencyStopCommandInterpretation() {
        val action1 = IntentParser.parse("Emergency stop")
        assertEquals(ActionType.EMERGENCY_STOP, action1.type)

        val action2 = IntentParser.parse("JARVIS ruko")
        assertEquals(ActionType.EMERGENCY_STOP, action2.type)
    }

    @Test
    fun testScreenUnderstandingCommandInterpretation() {
        val action1 = IntentParser.parse("JARVIS, screen par kya likha hai?")
        assertEquals(ActionType.UNDERSTAND_SCREEN, action1.type)

        val action2 = IntentParser.parse("Is page ka summary batao")
        assertEquals(ActionType.UNDERSTAND_SCREEN, action2.type)

        val action3 = IntentParser.parse("Is error ko samjhao")
        assertEquals(ActionType.UNDERSTAND_SCREEN, action3.type)
    }

    @Test
    fun testChromeCommandInterpretation() {
        val action = IntentParser.parse("JARVIS, Chrome mein Google kholo")
        assertEquals(ActionType.OPEN_APP, action.type)
        assertEquals("Google Chrome", action.parameters["appName"])
    }

    @Test
    fun testFloatingAssistantPreference() {
        val prefs = AssistantPreferences(context)
        prefs.isFloatingAssistantEnabled = true
        assertTrue(prefs.isFloatingAssistantEnabled)
        prefs.isFloatingAssistantEnabled = false
        assertFalse(prefs.isFloatingAssistantEnabled)
    }

    @Test
    fun testWakeWordPrefixCommands() {
        val ytAction = IntentParser.parse("Hey JARVIS, YouTube kholo")
        assertEquals(ActionType.OPEN_APP, ytAction.type)
        assertEquals("YouTube", ytAction.parameters["appName"])

        val chromeAction = IntentParser.parse("JARVIS, Chrome kholo")
        assertEquals(ActionType.OPEN_APP, chromeAction.type)
        assertEquals("Google Chrome", chromeAction.parameters["appName"])

        val waAction = IntentParser.parse("JARVIS, WhatsApp kholo")
        assertEquals(ActionType.OPEN_APP, waAction.type)
        assertEquals("WhatsApp", waAction.parameters["appName"])
    }

    @Test
    fun testScreenUnderstandingNewCommands() {
        val action1 = IntentParser.parse("JARVIS, screen par kya dikh raha hai?")
        assertEquals(ActionType.UNDERSTAND_SCREEN, action1.type)

        val action2 = IntentParser.parse("JARVIS, is page ka summary batao")
        assertEquals(ActionType.UNDERSTAND_SCREEN, action2.type)
    }

    @Test
    fun testScrollingAndNavigationCommands() {
        val scrollDown = IntentParser.parse("JARVIS, neeche scroll karo")
        assertEquals(ActionType.SCROLL_DOWN, scrollDown.type)

        val scrollUp = IntentParser.parse("JARVIS, upar scroll karo")
        assertEquals(ActionType.SCROLL_UP, scrollUp.type)

        val goBack = IntentParser.parse("JARVIS, back jao")
        assertEquals(ActionType.GO_BACK, goBack.type)

        val goHome = IntentParser.parse("JARVIS, home jao")
        assertEquals(ActionType.GO_HOME, goHome.type)
    }

    @Test
    fun testWakeWordAndScreenOffPreferences() {
        val prefs = AssistantPreferences(context)
        prefs.isWakeWordListeningEnabled = true
        assertTrue(prefs.isWakeWordListeningEnabled)
        prefs.isWakeWordListeningEnabled = false
        assertFalse(prefs.isWakeWordListeningEnabled)

        prefs.isScreenOffListeningEnabled = true
        assertTrue(prefs.isScreenOffListeningEnabled)
        prefs.isScreenOffListeningEnabled = false
        assertFalse(prefs.isScreenOffListeningEnabled)

        prefs.isVoiceResponseEnabled = true
        assertTrue(prefs.isVoiceResponseEnabled)
        prefs.isVoiceResponseEnabled = false
        assertFalse(prefs.isVoiceResponseEnabled)
    }
}
