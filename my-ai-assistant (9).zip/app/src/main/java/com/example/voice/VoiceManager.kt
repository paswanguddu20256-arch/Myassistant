package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class AssistantVoiceItem(
    val name: String,
    val localeName: String,
    val isFemaleSounding: Boolean,
    val rawVoice: Voice?
)

sealed interface VoiceState {
    data object Idle : VoiceState
    data object Listening : VoiceState
    data object Speaking : VoiceState
    data class Error(val message: String) : VoiceState
}

class VoiceManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit
) : RecognitionListener {

    private val TAG = "VoiceManager"

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<AssistantVoiceItem>>(emptyList())
    val availableVoices: StateFlow<List<AssistantVoiceItem>> = _availableVoices.asStateFlow()

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                loadAvailableVoices()
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _voiceState.value = VoiceState.Speaking
                    }

                    override fun onDone(utteranceId: String?) {
                        _voiceState.value = VoiceState.Idle
                    }

                    override fun onError(utteranceId: String?) {
                        _voiceState.value = VoiceState.Idle
                    }
                })
                Log.d(TAG, "TextToSpeech initialized successfully.")
            } else {
                Log.e(TAG, "TextToSpeech initialization failed with status $status")
            }
        }
    }

    fun loadAvailableVoices() {
        val tts = textToSpeech ?: return
        try {
            val voices = tts.voices
            if (!voices.isNullOrEmpty()) {
                val items = voices.filter { voice ->
                    val lang = voice.locale.language
                    lang == "hi" || lang == "en"
                }.map { voice ->
                    val isFemale = voice.name.contains("female", ignoreCase = true) ||
                            voice.name.contains("#female", ignoreCase = true) ||
                            voice.name.endsWith("-f", ignoreCase = true) ||
                            voice.name.contains("f0", ignoreCase = true)
                    AssistantVoiceItem(
                        name = voice.name,
                        localeName = voice.locale.displayName,
                        isFemaleSounding = isFemale,
                        rawVoice = voice
                    )
                }
                _availableVoices.value = items.ifEmpty { getDefaultVoiceList() }
            } else {
                _availableVoices.value = getDefaultVoiceList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching TTS voices", e)
            _availableVoices.value = getDefaultVoiceList()
        }
    }

    private fun getDefaultVoiceList(): List<AssistantVoiceItem> {
        return listOf(
            AssistantVoiceItem("Hindi Neural Voice (Female)", "Hindi (India)", isFemaleSounding = true, rawVoice = null),
            AssistantVoiceItem("Hindi Natural Voice (Male)", "Hindi (India)", isFemaleSounding = false, rawVoice = null),
            AssistantVoiceItem("English Indian Voice (Female)", "English (India)", isFemaleSounding = true, rawVoice = null),
            AssistantVoiceItem("English Jarvis Accent (Male)", "English (US)", isFemaleSounding = false, rawVoice = null)
        )
    }

    fun startListening(languageCode: String = "hi-IN") {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceState.value = VoiceState.Error("Speech recognition is not available on this device.")
            return
        }

        stopSpeaking()
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(this@VoiceManager)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageCode)
            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("hi-IN", "en-IN", "en-US"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        try {
            speechRecognizer?.startListening(intent)
            _voiceState.value = VoiceState.Listening
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening", e)
            _voiceState.value = VoiceState.Error("Listening start failed: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping listening", e)
        }
        if (_voiceState.value is VoiceState.Listening) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun speak(
        text: String,
        voiceName: String? = null,
        languageCode: String = "hi-IN",
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f
    ) {
        val tts = textToSpeech
        if (tts == null || !isTtsReady) {
            Log.w(TAG, "TTS not ready yet")
            return
        }

        tts.setPitch(pitch)
        tts.setSpeechRate(speechRate)

        // Set locale
        val locale = if (languageCode.startsWith("hi")) Locale("hi", "IN") else Locale("en", "IN")
        tts.language = locale

        // Set specific voice if selected and available
        if (!voiceName.isNullOrBlank()) {
            tts.voices?.firstOrNull { it.name == voiceName }?.let { selected ->
                tts.voice = selected
            }
        }

        _voiceState.value = VoiceState.Speaking
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        if (_voiceState.value is VoiceState.Speaking) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            textToSpeech?.shutdown()
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying VoiceManager", e)
        }
    }

    // RecognitionListener overrides
    override fun onReadyForSpeech(params: Bundle?) {
        _voiceState.value = VoiceState.Listening
    }

    override fun onBeginningOfSpeech() {}

    override fun onRmsChanged(rmsdB: Float) {
        _audioRms.value = rmsdB
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _voiceState.value = VoiceState.Idle
    }

    override fun onError(error: Int) {
        val errorMessage = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client speech error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
            SpeechRecognizer.ERROR_NETWORK -> "Network issue in voice recognition"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice network timed out"
            SpeechRecognizer.ERROR_NO_MATCH -> "Kuch samajh nahi aaya, kripya dobara bolein."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognizer is busy"
            SpeechRecognizer.ERROR_SERVER -> "Server recognition error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Aapne kuch nahi bola"
            else -> "Speech recognition error ($error)"
        }
        _voiceState.value = VoiceState.Error(errorMessage)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spokenText = matches[0]
            _voiceState.value = VoiceState.Idle
            onSpeechResult(spokenText)
        } else {
            _voiceState.value = VoiceState.Idle
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
