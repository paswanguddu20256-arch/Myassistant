package com.example.voice

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

sealed interface WakeWordState {
    data object Idle : WakeWordState
    data object ListeningForWakeWord : WakeWordState
    data class WakeWordTriggered(val keyword: String, val trailingCommand: String?) : WakeWordState
    data object Paused : WakeWordState
    data class Error(val message: String) : WakeWordState
}

class JarvisWakeWordDetector(
    private val context: Context,
    private val onWakeWordDetected: (keyword: String, trailingCommand: String?) -> Unit
) {

    private val TAG = "JarvisWakeWord"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    private val _detectorState = MutableStateFlow<WakeWordState>(WakeWordState.Idle)
    val detectorState: StateFlow<WakeWordState> = _detectorState.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    @Volatile
    private var isRunning = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognitionActive = false

    private val wakeWordPatterns = listOf(
        "hey jarvis",
        "jarvis",
        "hey jarvish",
        "hello jarvis",
        "ok jarvis",
        "हे जार्विस",
        "जार्विस"
    )

    fun start() {
        if (isRunning) return
        isRunning = true
        _detectorState.value = WakeWordState.ListeningForWakeWord
        Log.d(TAG, "Starting wake-word detection for 'Hey JARVIS' / 'JARVIS'...")
        mainHandler.post {
            startRecognitionCycle()
        }
    }

    fun stop() {
        isRunning = false
        _detectorState.value = WakeWordState.Idle
        mainHandler.post {
            destroyRecognizer()
        }
        Log.d(TAG, "Stopped wake-word detection.")
    }

    fun pause() {
        if (!isRunning) return
        _detectorState.value = WakeWordState.Paused
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                Log.w(TAG, "Error pausing recognizer", e)
            }
            isRecognitionActive = false
        }
    }

    fun resume() {
        if (!isRunning) return
        _detectorState.value = WakeWordState.ListeningForWakeWord
        mainHandler.post {
            startRecognitionCycle()
        }
    }

    private fun startRecognitionCycle() {
        if (!isRunning) return

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _detectorState.value = WakeWordState.Error("SpeechRecognizer is not available for wake-word.")
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createListener())
                }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                // Support both English and Hindi for wake word
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
                putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("en-US", "hi-IN", "en-IN"))
            }

            speechRecognizer?.startListening(intent)
            isRecognitionActive = true
            _detectorState.value = WakeWordState.ListeningForWakeWord
        } catch (e: Exception) {
            Log.e(TAG, "Error starting recognition cycle", e)
            scheduleRestart(1500L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (!isRunning) return
        mainHandler.postDelayed({
            if (isRunning) {
                startRecognitionCycle()
            }
        }, delayMs)
    }

    private fun destroyRecognizer() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying speech recognizer", e)
        } finally {
            speechRecognizer = null
            isRecognitionActive = false
        }
    }

    private fun checkTextForWakeWord(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        for (pattern in wakeWordPatterns) {
            val idx = lower.indexOf(pattern)
            if (idx != -1) {
                val trailing = lower.substring(idx + pattern.length).trim(' ', ',', ':', '!', '-')
                val originalTrailing = if (trailing.isNotBlank()) trailing else null

                Log.d(TAG, "Wake word matched: '$pattern', trailing command: '$originalTrailing'")
                _detectorState.value = WakeWordState.WakeWordTriggered(pattern, originalTrailing)

                // Temporarily pause recognizer while processing command
                try {
                    speechRecognizer?.stopListening()
                } catch (e: Exception) {
                    Log.w(TAG, "Error stopping after wake word match", e)
                }

                onWakeWordDetected(pattern, originalTrailing)
                return true
            }
        }
        return false
    }

    private fun createListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isRecognitionActive = true
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                _audioRms.value = rmsdB
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                isRecognitionActive = false
            }

            override fun onError(error: Int) {
                isRecognitionActive = false
                Log.d(TAG, "Recognition listener error code: $error")
                // Transient errors during continuous wake-word listening loop: restart quickly
                if (isRunning) {
                    val delay = when (error) {
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1000L
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> 3000L
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                            _detectorState.value = WakeWordState.Error("Microphone permission required.")
                            return
                        }
                        else -> 500L
                    }
                    scheduleRestart(delay)
                }
            }

            override fun onResults(results: Bundle?) {
                isRecognitionActive = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                var detected = false
                if (!matches.isNullOrEmpty()) {
                    for (match in matches) {
                        if (checkTextForWakeWord(match)) {
                            detected = true
                            break
                        }
                    }
                }

                // If not detected in this cycle, restart listening loop immediately
                if (isRunning && !detected) {
                    scheduleRestart(200L)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partials = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!partials.isNullOrEmpty()) {
                    for (partial in partials) {
                        if (checkTextForWakeWord(partial)) {
                            break
                        }
                    }
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }
}
