package com.example.voice

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.actions.ActionType
import com.example.actions.ExecutionResult
import com.example.actions.IntentParser
import com.example.actions.SmartActionExecutor
import com.example.ai.AiServiceResult
import com.example.ai.AssistantAiService
import com.example.data.preferences.AssistantPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JarvisWakeWordService : Service() {

    private val TAG = "JarvisWakeWordService"
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var preferences: AssistantPreferences
    private var wakeWordDetector: JarvisWakeWordDetector? = null
    private var commandVoiceManager: VoiceManager? = null
    private val aiService = AssistantAiService()

    private var wakeLock: PowerManager.WakeLock? = null
    private var isScreenOn = true

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    isScreenOn = false
                    Log.d(TAG, "Screen OFF event received.")
                    handleScreenOff()
                }
                Intent.ACTION_SCREEN_ON -> {
                    isScreenOn = true
                    Log.d(TAG, "Screen ON event received.")
                    handleScreenOn()
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        preferences = AssistantPreferences(this)
        _isServiceRunning.value = true
        _lastEventMessage.value = "Wake-word service started"

        createNotificationChannel()
        startForegroundServiceWithNotification("Listening for 'Hey JARVIS' or 'JARVIS'…")

        setupScreenReceiver()
        setupWakeLockIfEnabled()
        setupWakeWordDetector()
        setupCommandVoiceManager()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_LISTENING) {
            Log.d(TAG, "Stop listening action requested via notification.")
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun setupScreenReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, filter)
    }

    private fun setupWakeLockIfEnabled() {
        if (preferences.isScreenOffListeningEnabled) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Jarvis:WakeWordWakeLock").apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L) // 10 min safe timeout or until refreshed
            }
            Log.d(TAG, "Screen-off wake lock acquired.")
        }
    }

    private fun handleScreenOff() {
        if (!preferences.isScreenOffListeningEnabled) {
            Log.d(TAG, "Screen-off listening is disabled. Pausing wake-word detector to conserve battery.")
            wakeWordDetector?.pause()
            updateNotification("Screen off: Listening paused to save battery")
        } else {
            Log.d(TAG, "Screen-off listening is enabled. Keeping detector active (subject to OS background restrictions).")
            updateNotification("Screen off: Wake-word listening active")
        }
    }

    private fun handleScreenOn() {
        wakeWordDetector?.resume()
        updateNotification("Listening for 'Hey JARVIS' or 'JARVIS'…")
    }

    private fun setupWakeWordDetector() {
        wakeWordDetector = JarvisWakeWordDetector(this) { keyword, trailingCommand ->
            handleWakeWordTriggered(keyword, trailingCommand)
        }
        wakeWordDetector?.start()
    }

    private fun setupCommandVoiceManager() {
        commandVoiceManager = VoiceManager(this) { spokenCommand ->
            handleSpokenCommand(spokenCommand)
        }
    }

    private fun handleWakeWordTriggered(keyword: String, trailingCommand: String?) {
        _lastEventMessage.value = "Wake word detected: $keyword"
        Log.i(TAG, "Wake word triggered: '$keyword', trailing: '$trailingCommand'")

        if (!trailingCommand.isNullOrBlank()) {
            // User spoke both wake-word and command together e.g. "Hey JARVIS, YouTube kholo"
            handleSpokenCommand(trailingCommand)
        } else {
            // User only said "Hey JARVIS" -> Prompt and listen for next command
            updateNotification("Wake word detected! Listening to your command…")
            val promptText = if (preferences.language.startsWith("hi")) "हाँ जी, कहिए?" else "Yes, I am listening."
            if (preferences.isVoiceResponseEnabled) {
                commandVoiceManager?.speak(
                    text = promptText,
                    voiceName = preferences.voiceName,
                    languageCode = preferences.language,
                    pitch = preferences.speechPitch,
                    speechRate = preferences.speechRate
                )
            }
            // Delay slightly for speech prompt, then start listening for command
            serviceScope.launch {
                kotlinx.coroutines.delay(1200L)
                commandVoiceManager?.startListening(preferences.language)
            }
        }
    }

    private fun handleSpokenCommand(commandText: String) {
        if (commandText.isBlank()) {
            wakeWordDetector?.resume()
            return
        }

        _lastEventMessage.value = "Command: $commandText"
        Log.i(TAG, "Processing wake-word command: $commandText")

        serviceScope.launch {
            val action = IntentParser.parse(commandText)

            if (action.type == ActionType.EMERGENCY_STOP) {
                commandVoiceManager?.stopSpeaking()
                commandVoiceManager?.stopListening()
                speakIfEnabled("Emergency stop. Sabhi activities roki gayi.")
                wakeWordDetector?.resume()
                return@launch
            }

            if (action.type == ActionType.ANSWER_QUESTION) {
                val aiResult = aiService.generateResponse(action.parameters["prompt"] ?: commandText, emptyList())
                val reply = when (aiResult) {
                    is AiServiceResult.Success -> aiResult.responseText
                    is AiServiceResult.Error -> aiResult.message
                }
                speakIfEnabled(reply)
            } else {
                val result = SmartActionExecutor.execute(this@JarvisWakeWordService, action)
                val reply = when (result) {
                    is ExecutionResult.Success -> result.message
                    is ExecutionResult.Failure -> "Koshish vifal rahi: ${result.error}"
                    is ExecutionResult.NeedsConfirmation -> result.message
                }
                speakIfEnabled(reply)
            }

            // Resume wake-word detection after handling command
            wakeWordDetector?.resume()
        }
    }

    private fun speakIfEnabled(text: String) {
        if (preferences.isVoiceResponseEnabled) {
            val clean = text.replace(Regex("[*#_`]"), "").lines().take(2).joinToString(". ")
            commandVoiceManager?.speak(
                text = clean,
                voiceName = preferences.voiceName,
                languageCode = preferences.language,
                pitch = preferences.speechPitch,
                speechRate = preferences.speechRate
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.wake_word_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.wake_word_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    @SuppressLint("InlinedApi")
    private fun startForegroundServiceWithNotification(statusText: String) {
        val notification = buildNotification(statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(statusText: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(statusText))
    }

    private fun buildNotification(statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, JarvisWakeWordService::class.java).apply {
            action = ACTION_STOP_LISTENING
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.wake_word_listening_title))
            .setContentText(statusText)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "Stop Listening", stopPendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "Open JARVIS", openPendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false
        _lastEventMessage.value = "Service stopped"

        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
            Log.w(TAG, "Receiver not registered or already unregistered", e)
        }

        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock release error", e)
        }

        wakeWordDetector?.stop()
        commandVoiceManager?.destroy()
        serviceScope.cancel()
        Log.d(TAG, "JarvisWakeWordService destroyed.")
    }

    companion object {
        const val CHANNEL_ID = "jarvis_wake_word_service_channel"
        const val NOTIFICATION_ID = 505
        const val ACTION_STOP_LISTENING = "com.example.action.STOP_WAKE_WORD_LISTENING"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _lastEventMessage = MutableStateFlow<String?>(null)
        val lastEventMessage: StateFlow<String?> = _lastEventMessage.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, JarvisWakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, JarvisWakeWordService::class.java)
            context.stopService(intent)
        }
    }
}
