package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "JarvisAccessibilityService connected.")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        Log.d(TAG, "JarvisAccessibilityService unbind.")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Can be used to inspect active window titles or state changes
    }

    override fun onInterrupt() {
        Log.w(TAG, "JarvisAccessibilityService interrupted.")
    }

    companion object {
        private const val TAG = "JarvisAccessibility"
        var instance: JarvisAccessibilityService? = null
            private set

        fun isEnabled(context: Context): Boolean {
            if (instance != null) return true
            val expectedServiceName = "${context.packageName}/${JarvisAccessibilityService::class.java.canonicalName}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.contains(expectedServiceName) || enabledServices.contains(context.packageName)
        }

        fun scrollDown(): Boolean {
            val service = instance ?: return false

            // 1. Try finding a scrollable node first
            val root = service.rootInActiveWindow
            if (root != null) {
                val scrollableNode = findScrollableNode(root)
                if (scrollableNode != null) {
                    val performed = scrollableNode.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                    scrollableNode.recycle()
                    root.recycle()
                    if (performed) return true
                } else {
                    root.recycle()
                }
            }

            // 2. Fallback to gesture-based swipe up (which scrolls page down)
            return dispatchScrollGesture(service, scrollDown = true)
        }

        fun scrollUp(): Boolean {
            val service = instance ?: return false

            val root = service.rootInActiveWindow
            if (root != null) {
                val scrollableNode = findScrollableNode(root)
                if (scrollableNode != null) {
                    val performed = scrollableNode.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                    scrollableNode.recycle()
                    root.recycle()
                    if (performed) return true
                } else {
                    root.recycle()
                }
            }

            return dispatchScrollGesture(service, scrollDown = false)
        }

        fun goBack(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_BACK)
        }

        fun goHome(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_HOME)
        }

        fun openRecents(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_RECENTS)
        }

        fun openNotifications(): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        }

        private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (node.isScrollable) {
                return node
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val found = findScrollableNode(child)
                if (found != null) {
                    return found
                }
                child.recycle()
            }
            return null
        }

        private fun dispatchScrollGesture(service: AccessibilityService, scrollDown: Boolean): Boolean {
            val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)

            val screenWidth = metrics.widthPixels.toFloat()
            val screenHeight = metrics.heightPixels.toFloat()

            val startX = screenWidth / 2f
            val endX = screenWidth / 2f
            val startY = if (scrollDown) screenHeight * 0.72f else screenHeight * 0.28f
            val endY = if (scrollDown) screenHeight * 0.28f else screenHeight * 0.72f

            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }

            val stroke = GestureDescription.StrokeDescription(path, 0, 300)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            return service.dispatchGesture(gesture, null, null)
        }
    }
}
