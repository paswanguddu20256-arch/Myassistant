package com.example.floating

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.actions.ActionType
import com.example.actions.ExecutionResult
import com.example.actions.IntentParser
import com.example.actions.SmartAction
import com.example.actions.SmartActionExecutor
import com.example.ai.AiServiceResult
import com.example.ai.AssistantAiService
import com.example.data.preferences.AssistantPreferences
import com.example.voice.VoiceManager
import com.example.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatingJarvisService : Service() {

    private val TAG = "FloatingJarvisService"
    private val CHANNEL_ID = "jarvis_floating_assistant_channel"
    private val NOTIFICATION_ID = 404

    private lateinit var windowManager: WindowManager
    private lateinit var preferences: AssistantPreferences
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var rootView: FrameLayout? = null
    private var minimizedView: FrameLayout? = null
    private var expandedView: LinearLayout? = null
    private lateinit var windowLayoutParams: WindowManager.LayoutParams

    private var isExpanded = false
    private val aiService = AssistantAiService()
    private var voiceManager: VoiceManager? = null

    // UI references in expanded view
    private var statusTextView: TextView? = null
    private var responseTextView: TextView? = null
    private var micButton: Button? = null
    private var commandEditText: EditText? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        preferences = AssistantPreferences(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        if (!Settings.canDrawOverlays(this)) {
            Log.e(TAG, "Cannot start FloatingJarvisService: SYSTEM_ALERT_WINDOW permission missing")
            stopSelf()
            return
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())

        initVoiceManager()
        createFloatingOverlay()
    }

    private fun initVoiceManager() {
        voiceManager = VoiceManager(this) { spokenText ->
            handleFloatingCommand(spokenText)
        }

        serviceScope.launch {
            voiceManager?.voiceState?.collect { vState ->
                when (vState) {
                    VoiceState.Listening -> {
                        statusTextView?.text = "LISTENING… (बोलिए)"
                        statusTextView?.setTextColor(Color.parseColor("#00F2FE"))
                        micButton?.text = "Listening… Tap to Stop"
                    }
                    VoiceState.Speaking -> {
                        statusTextView?.text = "JARVIS SPEAKING…"
                        statusTextView?.setTextColor(Color.parseColor("#0A84FF"))
                        micButton?.text = "Speaking… Tap to Stop"
                    }
                    VoiceState.Idle -> {
                        statusTextView?.text = "JARVIS READY"
                        statusTextView?.setTextColor(Color.parseColor("#20E2D7"))
                        micButton?.text = "🎤 Tap to Speak"
                    }
                    is VoiceState.Error -> {
                        statusTextView?.text = "Voice Error"
                        statusTextView?.setTextColor(Color.parseColor("#FF453A"))
                        micButton?.text = "🎤 Tap to Speak"
                        responseTextView?.text = vState.message
                    }
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFloatingOverlay() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        windowLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 240
        }

        rootView = FrameLayout(this)

        // 1. Minimized View: Movable glowing circle
        minimizedView = createMinimizedOrbView()

        // 2. Expanded View: Compact Assistant HUD
        expandedView = createExpandedHudView()
        expandedView?.visibility = View.GONE

        rootView?.addView(minimizedView)
        rootView?.addView(expandedView)

        // Drag-to-move listener on minimized view
        minimizedView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var startClickTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = windowLayoutParams.x
                        initialY = windowLayoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        startClickTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        windowLayoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        windowLayoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(rootView, windowLayoutParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val clickDuration = System.currentTimeMillis() - startClickTime
                        val diffX = Math.abs(event.rawX - initialTouchX)
                        val diffY = Math.abs(event.rawY - initialTouchY)
                        if (clickDuration < 300 && diffX < 12 && diffY < 12) {
                            toggleExpand(true)
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(rootView, windowLayoutParams)
    }

    private fun createMinimizedOrbView(): FrameLayout {
        val size = dpToPx(60)
        val frame = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(size, size)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(Color.parseColor("#070B14"), Color.parseColor("#0A84FF"))
                setStroke(dpToPx(2), Color.parseColor("#00F2FE"))
            }
            background = bg
            elevation = dpToPx(8).toFloat()
        }

        val text = TextView(this).apply {
            text = "AI"
            setTextColor(Color.parseColor("#00F2FE"))
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        frame.addView(text)
        return frame
    }

    private fun createExpandedHudView(): LinearLayout {
        val width = dpToPx(320)
        val hud = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(18).toFloat()
                setColor(Color.parseColor("#F0080E1C"))
                setStroke(dpToPx(1), Color.parseColor("#3300F2FE"))
            }
            background = bg
            setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(14))
            elevation = dpToPx(12).toFloat()
        }

        // Top Bar: Status + Action Buttons (Emergency Stop, Minimize, Close)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        statusTextView = TextView(this).apply {
            text = "JARVIS READY"
            setTextColor(Color.parseColor("#00F2FE"))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        topBar.addView(statusTextView)

        // Emergency Stop Button
        val stopButton = Button(this).apply {
            text = "⛔ Stop"
            setTextColor(Color.WHITE)
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(Color.parseColor("#B3D32F2F"))
            }
            background = bg
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            setOnClickListener { emergencyStop() }
        }
        topBar.addView(stopButton)

        // Minimize Button
        val minButton = TextView(this).apply {
            text = "  —  "
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { toggleExpand(false) }
        }
        topBar.addView(minButton)

        // Close Button
        val closeButton = TextView(this).apply {
            text = " ✕ "
            setTextColor(Color.parseColor("#FF453A"))
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { stopSelf() }
        }
        topBar.addView(closeButton)

        hud.addView(topBar)

        // Speech / Mic Action Button
        micButton = Button(this).apply {
            text = "🎤 Tap to Speak (Hindi / English)"
            setTextColor(Color.parseColor("#070B14"))
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(12).toFloat()
                setColor(Color.parseColor("#00F2FE"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(42)
            ).apply {
                topMargin = dpToPx(10)
                bottomMargin = dpToPx(8)
            }
            setOnClickListener { toggleSpeechListening() }
        }
        hud.addView(micButton)

        // AI Response Box (Scrollable)
        val responseScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(100)
            )
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10).toFloat()
                setColor(Color.parseColor("#80111A2E"))
                setStroke(dpToPx(1), Color.parseColor("#2200F2FE"))
            }
            background = bg
            setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
        }

        responseTextView = TextView(this).apply {
            text = "JARVIS Floating Assistant active.\nTap mic or say: \"JARVIS, screen par kya likha hai?\" or \"YouTube kholo\"."
            setTextColor(Color.WHITE)
            textSize = 12f
            setLineSpacing(dpToPx(2).toFloat(), 1.0f)
        }
        responseScroll.addView(responseTextView)
        hud.addView(responseScroll)

        // Quick Action Chips Row
        val quickActionsScroll = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(8)
                bottomMargin = dpToPx(8)
            }
        }
        val quickActionsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        // Quick: Understand Screen
        quickActionsLayout.addView(createChip("👁️ Understand Screen") {
            triggerScreenUnderstanding("JARVIS, is page ka summary aur key details samjhao.")
        })

        // Quick: YouTube
        quickActionsLayout.addView(createChip("▶ YouTube") {
            handleFloatingCommand("YouTube kholo")
        })

        // Quick: WhatsApp
        quickActionsLayout.addView(createChip("💬 WhatsApp") {
            handleFloatingCommand("WhatsApp kholo")
        })

        // Quick: Chrome
        quickActionsLayout.addView(createChip("🌐 Chrome") {
            handleFloatingCommand("Chrome kholo")
        })

        quickActionsScroll.addView(quickActionsLayout)
        hud.addView(quickActionsScroll)

        // Text Input & Send Row
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        commandEditText = EditText(this).apply {
            hint = "Command in Hindi or English…"
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            textSize = 12f
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10).toFloat()
                setColor(Color.parseColor("#990B1324"))
                setStroke(dpToPx(1), Color.parseColor("#2200F2FE"))
            }
            background = bg
            setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6))
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1f)
            isSingleLine = true
        }
        inputRow.addView(commandEditText)

        val sendButton = Button(this).apply {
            text = "Send"
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10).toFloat()
                setColor(Color.parseColor("#0A84FF"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(56), dpToPx(38)).apply {
                leftMargin = dpToPx(6)
            }
            setOnClickListener {
                val input = commandEditText?.text?.toString()?.trim() ?: ""
                if (input.isNotBlank()) {
                    commandEditText?.setText("")
                    handleFloatingCommand(input)
                }
            }
        }
        inputRow.addView(sendButton)

        hud.addView(inputRow)

        return hud
    }

    private fun createChip(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.parseColor("#00F2FE"))
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(14).toFloat()
                setColor(Color.parseColor("#14223B"))
                setStroke(dpToPx(1), Color.parseColor("#3300F2FE"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dpToPx(32)
            ).apply {
                rightMargin = dpToPx(6)
            }
            setPadding(dpToPx(10), dpToPx(2), dpToPx(10), dpToPx(2))
            setOnClickListener { onClick() }
        }
    }

    private fun toggleExpand(expand: Boolean) {
        isExpanded = expand
        if (expand) {
            minimizedView?.visibility = View.GONE
            expandedView?.visibility = View.VISIBLE
            // Allow keyboard focus when expanded
            windowLayoutParams.flags = windowLayoutParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            expandedView?.visibility = View.GONE
            minimizedView?.visibility = View.VISIBLE
            // Pass touches through when minimized
            windowLayoutParams.flags = windowLayoutParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        windowManager.updateViewLayout(rootView, windowLayoutParams)
    }

    private fun toggleSpeechListening() {
        val vm = voiceManager ?: return
        if (vm.voiceState.value == VoiceState.Listening) {
            vm.stopListening()
        } else if (vm.voiceState.value == VoiceState.Speaking) {
            vm.stopSpeaking()
        } else {
            vm.startListening(preferences.language)
        }
    }

    private fun emergencyStop() {
        voiceManager?.stopListening()
        voiceManager?.stopSpeaking()
        statusTextView?.text = "EMERGENCY STOP EXECUTED"
        statusTextView?.setTextColor(Color.parseColor("#FF453A"))
        responseTextView?.text = "All voice recognition, pending actions, and audio responses cancelled."
        Toast.makeText(this, "JARVIS: All active tasks stopped", Toast.LENGTH_SHORT).show()
    }

    private fun handleFloatingCommand(text: String) {
        if (text.isBlank()) return

        serviceScope.launch {
            statusTextView?.text = "THINKING…"
            statusTextView?.setTextColor(Color.parseColor("#7928CA"))
            responseTextView?.text = "Command: \"$text\""

            val action = IntentParser.parse(text)

            when (action.type) {
                ActionType.EMERGENCY_STOP -> {
                    emergencyStop()
                }
                ActionType.UNDERSTAND_SCREEN -> {
                    triggerScreenUnderstanding(text)
                }
                ActionType.ANSWER_QUESTION -> {
                    val aiResult = aiService.generateResponse(action.parameters["prompt"] ?: text)
                    val reply = when (aiResult) {
                        is AiServiceResult.Success -> aiResult.responseText
                        is AiServiceResult.Error -> aiResult.message
                    }
                    displayAndSpeak(reply)
                }
                else -> {
                    statusTextView?.text = "EXECUTING…"
                    statusTextView?.setTextColor(Color.parseColor("#FF9500"))

                    val result = SmartActionExecutor.execute(this@FloatingJarvisService, action, userConfirmed = true)
                    val reply = when (result) {
                        is ExecutionResult.Success -> result.message + (result.details?.let { "\n$it" } ?: "")
                        is ExecutionResult.Failure -> "Failed: ${result.error}"
                        is ExecutionResult.NeedsConfirmation -> result.message
                    }
                    displayAndSpeak(reply)
                }
            }
        }
    }

    private fun triggerScreenUnderstanding(userQuestion: String) {
        statusTextView?.text = "CAPTURING SCREEN…"
        statusTextView?.setTextColor(Color.parseColor("#FF9500"))
        responseTextView?.text = "Screen snapshot request bheja ja raha hai. Consent approve karein."

        ScreenCaptureManager.requestScreenCapture(this) { bitmap ->
            serviceScope.launch {
                statusTextView?.text = "ANALYZING SCREEN…"
                statusTextView?.setTextColor(Color.parseColor("#00F2FE"))
                responseTextView?.text = "Screen content analyze ho raha hai..."

                val analysisResult = aiService.analyzeScreen(bitmap, userQuestion)
                val reply = when (analysisResult) {
                    is AiServiceResult.Success -> analysisResult.responseText
                    is AiServiceResult.Error -> analysisResult.message
                }
                displayAndSpeak(reply)
            }
        }
    }

    private fun displayAndSpeak(message: String) {
        responseTextView?.text = message
        statusTextView?.text = "JARVIS READY"
        statusTextView?.setTextColor(Color.parseColor("#00F2FE"))

        // Speak summary
        val cleanSpeech = message.replace(Regex("[*#_`]"), "")
            .lines().take(2).joinToString(". ")
        voiceManager?.speak(
            text = cleanSpeech,
            voiceName = preferences.voiceName,
            languageCode = preferences.language,
            pitch = preferences.speechPitch,
            speechRate = preferences.speechRate
        )
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Floating Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps JARVIS floating screen assistant active over other apps"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS Floating Assistant Active")
            .setContentText("Tap to open JARVIS • Movable orb is active over apps")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        voiceManager?.destroy()
        if (rootView != null) {
            try {
                windowManager.removeView(rootView)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing root view on destroy", e)
            }
        }
        preferences.isFloatingAssistantEnabled = false
    }
}
