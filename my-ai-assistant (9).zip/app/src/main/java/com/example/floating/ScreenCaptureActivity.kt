package com.example.floating

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class ScreenCaptureActivity : ComponentActivity() {

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = ScreenCaptureManager.pendingCaptureCallback
        ScreenCaptureManager.pendingCaptureCallback = null

        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            ScreenCaptureManager.captureScreen(this, result.resultCode, result.data!!) { bitmap ->
                callback?.invoke(bitmap)
                finish()
            }
        } else {
            Toast.makeText(this, "Screen understanding cancelled", Toast.LENGTH_SHORT).show()
            callback?.invoke(null)
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        if (projectionManager != null) {
            captureLauncher.launch(projectionManager.createScreenCaptureIntent())
        } else {
            ScreenCaptureManager.pendingCaptureCallback?.invoke(null)
            ScreenCaptureManager.pendingCaptureCallback = null
            finish()
        }
    }
}
