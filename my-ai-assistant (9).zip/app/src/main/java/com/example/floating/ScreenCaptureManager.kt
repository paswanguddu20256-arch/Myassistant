package com.example.floating

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

object ScreenCaptureManager {
    private const val TAG = "ScreenCaptureManager"

    var pendingCaptureCallback: ((Bitmap?) -> Unit)? = null

    fun requestScreenCapture(context: Context, callback: (Bitmap?) -> Unit) {
        pendingCaptureCallback = callback
        val intent = Intent(context, ScreenCaptureActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    @SuppressLint("WrongConstant")
    fun captureScreen(
        context: Context,
        resultCode: Int,
        data: Intent,
        onComplete: (Bitmap?) -> Unit
    ) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val width = (metrics.widthPixels / 2).coerceAtLeast(360)
        val height = (metrics.heightPixels / 2).coerceAtLeast(640)
        val density = metrics.densityDpi

        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mediaProjection: MediaProjection? = try {
            projectionManager.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get MediaProjection", e)
            null
        }

        if (mediaProjection == null) {
            onComplete(null)
            return
        }

        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null

        val handler = Handler(Looper.getMainLooper())

        // Timeout fallback after 3 seconds in case frame is delayed
        val timeoutRunnable = Runnable {
            try {
                virtualDisplay?.release()
                mediaProjection.stop()
                imageReader.close()
            } catch (e: Exception) {
                Log.w(TAG, "Cleanup error on timeout", e)
            }
            onComplete(null)
        }
        handler.postDelayed(timeoutRunnable, 3000L)

        imageReader.setOnImageAvailableListener({ reader ->
            handler.removeCallbacks(timeoutRunnable)
            var bitmap: Bitmap? = null
            try {
                val image = reader.acquireLatestImage()
                if (image != null) {
                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * width

                    bitmap = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.copyPixelsFromBuffer(buffer)
                    image.close()

                    // Crop to exact width if row padding was added
                    if (bitmap.width != width) {
                        val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                        bitmap.recycle()
                        bitmap = cropped
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error acquiring screen frame", e)
            } finally {
                try {
                    virtualDisplay?.release()
                    mediaProjection.stop()
                    imageReader.close()
                } catch (e: Exception) {
                    Log.w(TAG, "Error during cleanup", e)
                }
                onComplete(bitmap)
            }
        }, handler)

        try {
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "JarvisScreenCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                handler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create VirtualDisplay", e)
            handler.removeCallbacks(timeoutRunnable)
            mediaProjection.stop()
            imageReader.close()
            onComplete(null)
        }
    }
}
