package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.screens.AppLauncherScreen
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.ImageStudioScreen
import com.example.ui.screens.ProgressDashboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VoiceStudioScreen
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkBackground
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandated by Firebase AI Logic skill: Configure App Check before setContent or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Runtime Permission for Microphone
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Microphone permission granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Microphone permission is required for voice commands", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Handle back button to return to Game screen if on sub-screen
    BackHandler(enabled = currentScreen != AppScreen.GAME) {
        viewModel.navigateTo(AppScreen.GAME)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = JarvisDarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = JarvisDarkSurface,
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.GAME,
                    onClick = { viewModel.navigateTo(AppScreen.GAME) },
                    icon = { Icon(Icons.Default.SportsEsports, contentDescription = "Game") },
                    label = { Text("Game", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFFD700),
                        selectedTextColor = Color(0xFFFFD700),
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = Color(0x33FFD700)
                    ),
                    modifier = Modifier.testTag("nav_game")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.ASSISTANT,
                    onClick = { viewModel.navigateTo(AppScreen.ASSISTANT) },
                    icon = { Icon(Icons.Default.SmartToy, contentDescription = "Assistant") },
                    label = { Text("Assistant", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        selectedTextColor = JarvisCyan,
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = JarvisCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_assistant")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.VOICE_STUDIO,
                    onClick = { viewModel.navigateTo(AppScreen.VOICE_STUDIO) },
                    icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = "Voice Studio") },
                    label = { Text("Voices", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        selectedTextColor = JarvisCyan,
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = JarvisCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_voices")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.APPS,
                    onClick = { viewModel.navigateTo(AppScreen.APPS) },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "Apps") },
                    label = { Text("Apps", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        selectedTextColor = JarvisCyan,
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = JarvisCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_apps")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.IMAGE_STUDIO,
                    onClick = { viewModel.navigateTo(AppScreen.IMAGE_STUDIO) },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Image Studio") },
                    label = { Text("Images", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        selectedTextColor = JarvisCyan,
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = JarvisCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_images")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.PROGRESS,
                    onClick = { viewModel.navigateTo(AppScreen.PROGRESS) },
                    icon = { Icon(Icons.Default.Checklist, contentDescription = "Progress") },
                    label = { Text("Progress", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        selectedTextColor = JarvisCyan,
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = JarvisCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_progress")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.SETTINGS,
                    onClick = { viewModel.navigateTo(AppScreen.SETTINGS) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        selectedTextColor = JarvisCyan,
                        unselectedIconColor = Color(0xFF8B9CB5),
                        unselectedTextColor = Color(0xFF8B9CB5),
                        indicatorColor = JarvisCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        }
    ) { innerPadding ->
        when (currentScreen) {
            AppScreen.GAME -> GameScreen(modifier = Modifier.padding(innerPadding))
            AppScreen.ASSISTANT -> AssistantScreen(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            AppScreen.VOICE_STUDIO -> VoiceStudioScreen(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            AppScreen.APPS -> AppLauncherScreen(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            AppScreen.IMAGE_STUDIO -> ImageStudioScreen(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            AppScreen.PROGRESS -> ProgressDashboardScreen(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
        }
    }
}
