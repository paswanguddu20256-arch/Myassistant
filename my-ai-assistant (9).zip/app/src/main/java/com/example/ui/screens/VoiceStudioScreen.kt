package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.JarvisBlue
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkBackground
import com.example.ui.theme.JarvisDarkBorder
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisDarkSurfaceVariant
import com.example.ui.theme.JarvisGreen
import com.example.voice.AssistantVoiceItem

@Composable
fun VoiceStudioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val voices by viewModel.availableVoices.collectAsState()
    val currentVoiceName = viewModel.preferences.voiceName

    var speechRate by remember { mutableFloatStateOf(viewModel.preferences.speechRate) }
    var speechPitch by remember { mutableFloatStateOf(viewModel.preferences.speechPitch) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisDarkBackground)
            .padding(16.dp)
    ) {
        // Title & Refresh
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Voice Studio",
                    color = JarvisCyan,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Aawaz aur bolne ki gati customise karein",
                    color = Color(0xFF8B9CB5),
                    fontSize = 13.sp
                )
            }

            IconButton(
                onClick = { viewModel.voiceManager.loadAvailableVoices() },
                modifier = Modifier.testTag("refresh_voices_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh voices",
                    tint = JarvisCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Sliders Card: Pitch & Rate
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Speech Rate
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Speech Speed (Gati)", color = Color.White, fontSize = 13.sp)
                    Text(String.format("%.1fx", speechRate), color = JarvisCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = speechRate,
                    onValueChange = {
                        speechRate = it
                        viewModel.updateSpeechRate(it)
                    },
                    valueRange = 0.6f..1.6f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan,
                        inactiveTrackColor = JarvisDarkSurfaceVariant
                    ),
                    modifier = Modifier.testTag("speech_rate_slider")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Speech Pitch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Voice Pitch (Sur)", color = Color.White, fontSize = 13.sp)
                    Text(String.format("%.1fx", speechPitch), color = JarvisCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = speechPitch,
                    onValueChange = {
                        speechPitch = it
                        viewModel.updateSpeechPitch(it)
                    },
                    valueRange = 0.6f..1.5f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisBlue,
                        activeTrackColor = JarvisBlue,
                        inactiveTrackColor = JarvisDarkSurfaceVariant
                    ),
                    modifier = Modifier.testTag("speech_pitch_slider")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Header for Voice List
        Text(
            text = "Available Assistant Voices (${voices.size})",
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Voice List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(voices) { voice ->
                val isSelected = voice.name == currentVoiceName || (currentVoiceName == null && voice == voices.firstOrNull())
                VoiceItemCard(
                    voice = voice,
                    isSelected = isSelected,
                    onSelect = { viewModel.selectVoice(voice) }
                )
            }
        }
    }
}

@Composable
fun VoiceItemCard(
    voice: AssistantVoiceItem,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) JarvisDarkSurfaceVariant else JarvisDarkSurface
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) JarvisCyan else JarvisDarkBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) JarvisCyan.copy(alpha = 0.2f) else JarvisDarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = if (isSelected) JarvisCyan else Color(0xFF8B9CB5),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = voice.name,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (voice.isFemaleSounding) Color(0xFF4A154B) else Color(0xFF0F3460)
                        ) {
                            Text(
                                text = if (voice.isFemaleSounding) "Female" else "Male",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = voice.localeName,
                            color = Color(0xFF8B9CB5),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Preview / Select Button
            Button(
                onClick = onSelect,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSelected) JarvisGreen else JarvisCyan
                ),
                shape = RoundedCornerShape(20.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("preview_voice_${voice.name}")
            ) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.Check else Icons.Default.PlayArrow,
                    contentDescription = "Test voice",
                    tint = Color(0xFF070B14),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isSelected) "Active" else "Preview",
                    color = Color(0xFF070B14),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
