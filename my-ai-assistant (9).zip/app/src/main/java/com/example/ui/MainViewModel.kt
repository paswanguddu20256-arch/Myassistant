package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.floating.FloatingJarvisService
import com.example.floating.ScreenCaptureManager
import com.example.actions.ActionExecutionStatus
import com.example.actions.ActionType
import com.example.actions.ExecutionResult
import com.example.actions.InstalledAppInfo
import com.example.actions.IntentParser
import com.example.actions.SmartAction
import com.example.actions.SmartActionExecutor
import com.example.ai.AiServiceResult
import com.example.ai.AssistantAiService
import com.example.data.db.AppDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.FeatureProgressEntity
import com.example.data.preferences.AssistantPreferences
import com.example.progress.ProgressTracker
import com.example.voice.AssistantVoiceItem
import com.example.voice.VoiceManager
import com.example.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AssistantStatus {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    EXECUTING
}

enum class AppScreen {
    GAME,
    ASSISTANT,
    VOICE_STUDIO,
    APPS,
    IMAGE_STUDIO,
    PROGRESS,
    SETTINGS
}

data class ConfirmationDialogState(
    val isOpen: Boolean = false,
    val action: SmartAction? = null,
    val promptMessage: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val chatDao = db.chatMessageDao()
    private val progressDao = db.featureProgressDao()
    val preferences = AssistantPreferences(application)
    val progressTracker = ProgressTracker(application, progressDao)
    private val aiService = AssistantAiService()

    private val _currentScreen = MutableStateFlow(AppScreen.GAME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _assistantStatus = MutableStateFlow(AssistantStatus.IDLE)
    val assistantStatus: StateFlow<AssistantStatus> = _assistantStatus.asStateFlow()

    val chatMessages: StateFlow<List<ChatMessageEntity>> = chatDao.getAllMessagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val progressItems: StateFlow<List<FeatureProgressEntity>> = progressDao.getAllProgressFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _confirmationDialog = MutableStateFlow(ConfirmationDialogState())
    val confirmationDialog: StateFlow<ConfirmationDialogState> = _confirmationDialog.asStateFlow()

    private val _imagePrompt = MutableStateFlow("")
    val imagePrompt: StateFlow<String> = _imagePrompt.asStateFlow()

    private val _selectedAspectRatio = MutableStateFlow("1:1")
    val selectedAspectRatio: StateFlow<String> = _selectedAspectRatio.asStateFlow()

    private val _imageStudioStatus = MutableStateFlow<String?>(null)
    val imageStudioStatus: StateFlow<String?> = _imageStudioStatus.asStateFlow()

    private val _isFloatingActive = MutableStateFlow(preferences.isFloatingAssistantEnabled)
    val isFloatingActive: StateFlow<Boolean> = _isFloatingActive.asStateFlow()

    val isWakeWordServiceRunning: StateFlow<Boolean> = com.example.voice.JarvisWakeWordService.isServiceRunning

    private val _isWakeWordEnabled = MutableStateFlow(preferences.isWakeWordListeningEnabled)
    val isWakeWordEnabled: StateFlow<Boolean> = _isWakeWordEnabled.asStateFlow()

    private val _isScreenOffListeningEnabled = MutableStateFlow(preferences.isScreenOffListeningEnabled)
    val isScreenOffListeningEnabled: StateFlow<Boolean> = _isScreenOffListeningEnabled.asStateFlow()

    private val _isVoiceResponseEnabled = MutableStateFlow(preferences.isVoiceResponseEnabled)
    val isVoiceResponseEnabled: StateFlow<Boolean> = _isVoiceResponseEnabled.asStateFlow()

    val voiceManager: VoiceManager by lazy {
        VoiceManager(application) { recognizedSpeech ->
            handleUserMessage(recognizedSpeech)
        }
    }

    val audioRms: StateFlow<Float> by lazy { voiceManager.audioRms }
    val availableVoices: StateFlow<List<AssistantVoiceItem>> by lazy { voiceManager.availableVoices }

    init {
        viewModelScope.launch {
            progressTracker.initializeFeaturesIfEmpty()
            loadInstalledApps()
        }

        viewModelScope.launch {
            voiceManager.voiceState.collect { vState ->
                when (vState) {
                    VoiceState.Idle -> {
                        if (_assistantStatus.value == AssistantStatus.LISTENING || _assistantStatus.value == AssistantStatus.SPEAKING) {
                            _assistantStatus.value = AssistantStatus.IDLE
                        }
                    }
                    VoiceState.Listening -> _assistantStatus.value = AssistantStatus.LISTENING
                    VoiceState.Speaking -> _assistantStatus.value = AssistantStatus.SPEAKING
                    is VoiceState.Error -> {
                        _assistantStatus.value = AssistantStatus.IDLE
                        addAssistantMessage("Aawaz me samasya: ${vState.message}")
                    }
                }
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun toggleListening() {
        if (_assistantStatus.value == AssistantStatus.LISTENING) {
            voiceManager.stopListening()
            _assistantStatus.value = AssistantStatus.IDLE
        } else {
            voiceManager.startListening(preferences.language)
        }
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
        _assistantStatus.value = AssistantStatus.IDLE
    }

    fun handleUserMessage(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            // 1. Insert user message in database
            chatDao.insertMessage(
                ChatMessageEntity(
                    text = text,
                    isUser = true
                )
            )

            _assistantStatus.value = AssistantStatus.THINKING

            // 2. Parse Intent
            val action = IntentParser.parse(text)

            // If action requires confirmation (e.g. messaging externally)
            if (action.requiresConfirmation) {
                _assistantStatus.value = AssistantStatus.IDLE
                _confirmationDialog.value = ConfirmationDialogState(
                    isOpen = true,
                    action = action,
                    promptMessage = action.description
                )
                return@launch
            }

            // 3. Process action or query AI
            processAction(action)
        }
    }

    private suspend fun processAction(action: SmartAction, userConfirmed: Boolean = false) {
        if (action.type == ActionType.EMERGENCY_STOP) {
            emergencyStop()
            return
        }

        if (action.type == ActionType.UNDERSTAND_SCREEN) {
            triggerUnderstandScreen(action.parameters["query"] ?: "Screen par kya likha hai?")
            return
        }

        if (action.type == ActionType.ANSWER_QUESTION) {
            // Conversational query -> Send to Gemini / AssistantAiService
            val contextHistory = chatMessages.value.takeLast(6).map { it.text to it.isUser }
            val aiResult = aiService.generateResponse(action.parameters["prompt"] ?: "", contextHistory)

            val replyText = when (aiResult) {
                is AiServiceResult.Success -> aiResult.responseText
                is AiServiceResult.Error -> aiResult.message
            }

            _assistantStatus.value = AssistantStatus.SPEAKING
            addAssistantMessage(replyText)
            speakResponse(replyText)
        } else {
            _assistantStatus.value = AssistantStatus.EXECUTING

            // Execute phone action
            val executionResult = SmartActionExecutor.execute(getApplication(), action, userConfirmed)

            val (msg, statusString) = when (executionResult) {
                is ExecutionResult.Success -> {
                    val fullMsg = if (executionResult.details != null) {
                        "${executionResult.message}\n(${executionResult.details})"
                    } else {
                        executionResult.message
                    }
                    fullMsg to "COMPLETED"
                }
                is ExecutionResult.Failure -> {
                    val errorMsg = "Koshish vifal rahi: ${executionResult.error}" +
                            if (executionResult.suggestion != null) "\nSujhav: ${executionResult.suggestion}" else ""
                    errorMsg to "FAILED"
                }
                is ExecutionResult.NeedsConfirmation -> {
                    _confirmationDialog.value = ConfirmationDialogState(
                        isOpen = true,
                        action = action,
                        promptMessage = executionResult.message
                    )
                    _assistantStatus.value = AssistantStatus.IDLE
                    return
                }
            }

            addAssistantMessage(
                text = msg,
                actionType = action.type.name,
                actionStatus = statusString
            )

            // If it navigated to another screen, switch tab
            if (action.type == ActionType.GENERATE_IMAGE) {
                _currentScreen.value = AppScreen.IMAGE_STUDIO
                _imagePrompt.value = action.parameters["prompt"] ?: ""
            } else if (action.type == ActionType.CHANGE_ASSISTANT_VOICE) {
                _currentScreen.value = AppScreen.VOICE_STUDIO
            } else if (action.type == ActionType.SHOW_INSTALLED_APPS) {
                _currentScreen.value = AppScreen.APPS
            }

            speakResponse(msg)
        }
    }

    fun confirmPendingAction() {
        val action = _confirmationDialog.value.action
        _confirmationDialog.value = ConfirmationDialogState(isOpen = false, action = null)
        if (action != null) {
            viewModelScope.launch {
                processAction(action, userConfirmed = true)
            }
        }
    }

    fun dismissPendingAction() {
        val action = _confirmationDialog.value.action
        _confirmationDialog.value = ConfirmationDialogState(isOpen = false, action = null)
        if (action != null) {
            viewModelScope.launch {
                addAssistantMessage("Action cancel kiya gaya.")
                _assistantStatus.value = AssistantStatus.IDLE
            }
        }
    }

    private suspend fun addAssistantMessage(
        text: String,
        actionType: String? = null,
        actionStatus: String? = null
    ) {
        chatDao.insertMessage(
            ChatMessageEntity(
                text = text,
                isUser = false,
                actionType = actionType,
                actionStatus = actionStatus
            )
        )
    }

    private fun speakResponse(text: String) {
        if (!preferences.isVoiceResponseEnabled) {
            return
        }
        // Strip markdown if any for TTS cleanliness
        val cleanSpeech = text.replace(Regex("[*#_`]"), "")
            .lines().take(2).joinToString(". ")
        voiceManager.speak(
            text = cleanSpeech,
            voiceName = preferences.voiceName,
            languageCode = preferences.language,
            pitch = preferences.speechPitch,
            speechRate = preferences.speechRate
        )
    }

    fun selectVoice(voice: AssistantVoiceItem) {
        preferences.voiceName = voice.name
        voiceManager.speak(
            text = "Namaste, yeh meri nayi aawaz ka sample hai.",
            voiceName = voice.name,
            languageCode = preferences.language,
            pitch = preferences.speechPitch,
            speechRate = preferences.speechRate
        )
    }

    fun updateSpeechPitch(pitch: Float) {
        preferences.speechPitch = pitch
    }

    fun updateSpeechRate(rate: Float) {
        preferences.speechRate = rate
    }

    fun setLanguage(lang: String) {
        preferences.language = lang
    }

    fun setImagePrompt(prompt: String) {
        _imagePrompt.value = prompt
    }

    fun setAspectRatio(ratio: String) {
        _selectedAspectRatio.value = ratio
    }

    fun generateImageFromPrompt() {
        val prompt = _imagePrompt.value.trim()
        if (prompt.isBlank()) return
        _imageStudioStatus.value = "AI Image Generator taiyar ho raha hai: \"$prompt\" ($selectedAspectRatio)..."
        viewModelScope.launch {
            // Surface real requirement and status
            _imageStudioStatus.value = "Image prompt: \"$prompt\"\nAspect Ratio: ${_selectedAspectRatio.value}\nStatus: Ready for generation. Live Imagen generation requires Firebase Blaze project credentials."
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = SmartActionExecutor.getInstalledLaunchableApps(getApplication())
            _installedApps.value = apps
        }
    }

    fun runProgressDiagnostics() {
        viewModelScope.launch {
            progressTracker.runAutomatedDiagnosticTests()
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            chatDao.clearHistory()
        }
    }

    fun emergencyStop() {
        voiceManager.stopListening()
        voiceManager.stopSpeaking()
        _assistantStatus.value = AssistantStatus.IDLE
        viewModelScope.launch {
            addAssistantMessage("⛔ Emergency stop: Sabhi actions aur speech turant roki gayi.")
        }
    }

    fun triggerUnderstandScreen(query: String = "JARVIS, is screen ka summary batao.") {
        viewModelScope.launch {
            _assistantStatus.value = AssistantStatus.THINKING
            addAssistantMessage("Screen Snapshot request bheja ja raha hai. Consent approve karein...")

            ScreenCaptureManager.requestScreenCapture(getApplication()) { bitmap ->
                viewModelScope.launch {
                    _assistantStatus.value = AssistantStatus.THINKING
                    val visionResult = aiService.analyzeScreen(bitmap, query)
                    val reply = when (visionResult) {
                        is AiServiceResult.Success -> visionResult.responseText
                        is AiServiceResult.Error -> visionResult.message
                    }
                    _assistantStatus.value = AssistantStatus.SPEAKING
                    addAssistantMessage(reply, actionType = "UNDERSTAND_SCREEN", actionStatus = "COMPLETED")
                    speakResponse(reply)
                }
            }
        }
    }

    fun toggleFloatingAssistant(context: Context, enable: Boolean): Boolean {
        if (enable) {
            if (!Settings.canDrawOverlays(context)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return false
            }
            val intent = Intent(context, FloatingJarvisService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            preferences.isFloatingAssistantEnabled = true
            _isFloatingActive.value = true
            return true
        } else {
            val intent = Intent(context, FloatingJarvisService::class.java)
            context.stopService(intent)
            preferences.isFloatingAssistantEnabled = false
            _isFloatingActive.value = false
            return true
        }
    }

    fun toggleWakeWordListening(context: Context, enable: Boolean) {
        preferences.isWakeWordListeningEnabled = enable
        _isWakeWordEnabled.value = enable
        if (enable) {
            com.example.voice.JarvisWakeWordService.start(context)
        } else {
            com.example.voice.JarvisWakeWordService.stop(context)
        }
    }

    fun toggleScreenOffListening(context: Context, enable: Boolean) {
        preferences.isScreenOffListeningEnabled = enable
        _isScreenOffListeningEnabled.value = enable
        if (isWakeWordServiceRunning.value) {
            com.example.voice.JarvisWakeWordService.start(context)
        }
    }

    fun toggleVoiceResponse(enable: Boolean) {
        preferences.isVoiceResponseEnabled = enable
        _isVoiceResponseEnabled.value = enable
        if (!enable) {
            voiceManager.stopSpeaking()
        }
    }

    fun stopListeningNow(context: Context) {
        voiceManager.stopListening()
        com.example.voice.JarvisWakeWordService.stop(context)
        preferences.isWakeWordListeningEnabled = false
        _isWakeWordEnabled.value = false
        _assistantStatus.value = AssistantStatus.IDLE
        viewModelScope.launch {
            addAssistantMessage("Sabhi voice listening services (Microphone & Wake Word) turant band ki gayi.")
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
