package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Jarvis Color Palette
val JarvisCyan = Color(0xFF00F2FE)
val JarvisBlue = Color(0xFF0A84FF)
val JarvisTeal = Color(0xFF20E2D7)
val JarvisPurple = Color(0xFF8A2BE2)
val JarvisOrange = Color(0xFFFF9500)
val JarvisGreen = Color(0xFF30D158)
val JarvisRed = Color(0xFFFF453A)

// Dark Theme Backgrounds & Surfaces
val JarvisDarkBackground = Color(0xFF070B14)
val JarvisDarkSurface = Color(0xFF0E1626)
val JarvisDarkSurfaceVariant = Color(0xFF162238)
val JarvisDarkBorder = Color(0x3300F2FE)
val JarvisDarkTextPrimary = Color(0xFFF0F6FC)
val JarvisDarkTextSecondary = Color(0xFF8B9CB5)

// Light Theme
val JarvisLightPrimary = Color(0xFF0066CC)
val JarvisLightBackground = Color(0xFFF4F7FC)
val JarvisLightSurface = Color(0xFFFFFFFF)
val JarvisLightSurfaceVariant = Color(0xFFE2EAF5)
val JarvisLightTextPrimary = Color(0xFF0D1B2A)
val JarvisLightTextSecondary = Color(0xFF415A77)
