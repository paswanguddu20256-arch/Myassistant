package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.AssistantStatus
import com.example.ui.theme.JarvisBlue
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisOrange
import com.example.ui.theme.JarvisPurple
import com.example.ui.theme.JarvisTeal
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisOrb(
    status: AssistantStatus,
    audioRms: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 190.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "jarvis_orb_transition")

    // Rotation animation for holographic rings
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rotation"
    )

    // Pulse animation for core breathing
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    // Dynamic wave expansion derived from speech RMS
    val rmsScale = (1.0f + (audioRms.coerceIn(0f, 12f) / 14f)).coerceIn(1.0f, 1.8f)

    // Colors depending on active state
    val (primaryGlow, accentGlow) = when (status) {
        AssistantStatus.LISTENING -> JarvisCyan to JarvisTeal
        AssistantStatus.THINKING -> JarvisPurple to JarvisBlue
        AssistantStatus.SPEAKING -> JarvisBlue to JarvisCyan
        AssistantStatus.EXECUTING -> JarvisOrange to JarvisGreen
        AssistantStatus.IDLE -> JarvisCyan.copy(alpha = 0.85f) to JarvisBlue.copy(alpha = 0.7f)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2.6f) * if (status == AssistantStatus.LISTENING) rmsScale else pulseScale

            // 1. Outermost subtle ambient glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(primaryGlow.copy(alpha = 0.28f), Color.Transparent),
                    center = center,
                    radius = baseRadius * 1.55f
                ),
                radius = baseRadius * 1.55f,
                center = center
            )

            // 2. Outer segmented holographic ring (rotates counter-clockwise)
            val outerRadius = baseRadius * 1.25f
            drawCircle(
                color = accentGlow.copy(alpha = 0.45f),
                radius = outerRadius,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 14f, 8f, 14f), rotationAngle * 0.5f)
                )
            )

            // 3. Middle dashed energy ring (rotates clockwise)
            val midRadius = baseRadius * 1.08f
            drawCircle(
                color = primaryGlow.copy(alpha = 0.7f),
                radius = midRadius,
                center = center,
                style = Stroke(
                    width = 2.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(35f, 18f), -rotationAngle)
                )
            )

            // 4. Orbital Tech Nodes
            val nodeCount = 4
            for (i in 0 until nodeCount) {
                val angleRad = Math.toRadians((rotationAngle + (i * 360f / nodeCount)).toDouble())
                val nodeOffset = Offset(
                    x = center.x + (midRadius * cos(angleRad)).toFloat(),
                    y = center.y + (midRadius * sin(angleRad)).toFloat()
                )
                drawCircle(
                    color = primaryGlow,
                    radius = 3.5.dp.toPx(),
                    center = nodeOffset
                )
            }

            // 5. Center Core Glowing Orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        primaryGlow,
                        accentGlow,
                        accentGlow.copy(alpha = 0.15f)
                    ),
                    center = center,
                    radius = baseRadius * 0.75f
                ),
                radius = baseRadius * 0.75f,
                center = center
            )

            // 6. Center Jarvis AI node ring
            drawCircle(
                color = Color.White.copy(alpha = 0.9f),
                radius = baseRadius * 0.25f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}
