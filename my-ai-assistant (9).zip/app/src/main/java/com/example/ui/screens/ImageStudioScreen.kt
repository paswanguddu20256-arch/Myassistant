package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkBackground
import com.example.ui.theme.JarvisDarkBorder
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisDarkSurfaceVariant
import com.example.ui.theme.JarvisOrange
import com.example.ui.theme.JarvisPurple

@Composable
fun ImageStudioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val prompt by viewModel.imagePrompt.collectAsState()
    val ratio by viewModel.selectedAspectRatio.collectAsState()
    val statusText by viewModel.imageStudioStatus.collectAsState()

    val ratios = listOf("1:1", "16:9", "9:16", "4:3")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisDarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            text = "AI Image Generator",
            color = JarvisCyan,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Describe your image in Hindi, Hinglish, or English",
            color = Color(0xFF8B9CB5),
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Example Prompts
        Text(
            text = "Try these sample prompts:",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SuggestionChip(
                label = "Sunset ke samay pahadon ke beech futuristic city",
                onClick = {
                    viewModel.setImagePrompt("Ek cinematic image banao jismein sunset ke samay pahadon ke beech ek futuristic city ho, glowing neon lights, photorealistic 8k.")
                }
            )
            SuggestionChip(
                label = "Cyberpunk Jarvis AI robot in Mumbai",
                onClick = {
                    viewModel.setImagePrompt("Cyberpunk Jarvis AI assistant hologram floating inside a futuristic tech laboratory in Mumbai, neon teal glow, cinematic lighting.")
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Prompt Input
        OutlinedTextField(
            value = prompt,
            onValueChange = { viewModel.setImagePrompt(it) },
            label = { Text("Image Description Prompt") },
            placeholder = { Text("e.g. Ek sundar sunset aur tech city…") },
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .testTag("image_prompt_input"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisCyan,
                unfocusedBorderColor = JarvisDarkBorder,
                focusedContainerColor = JarvisDarkSurface,
                unfocusedContainerColor = JarvisDarkSurface,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Aspect Ratio Selector
        Text(
            text = "Aspect Ratio",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            ratios.forEach { item ->
                val isSelected = item == ratio
                Surface(
                    onClick = { viewModel.setAspectRatio(item) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) JarvisCyan else JarvisDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) JarvisCyan else JarvisDarkBorder),
                    modifier = Modifier.testTag("ratio_chip_$item")
                ) {
                    Text(
                        text = item,
                        color = if (isSelected) Color(0xFF070B14) else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Generate Action Button
        Button(
            onClick = { viewModel.generateImageFromPrompt() },
            colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("generate_image_button")
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF070B14))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Generate Image",
                color = Color(0xFF070B14),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Status Card / Honest Backend Requirement Information
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = JarvisOrange,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Model & Backend Configuration",
                        color = JarvisOrange,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (statusText != null) {
                        statusText!!
                    } else {
                        "Model: gemini-nano-banana-2.1 / Imagen\n" +
                                "Live runtime image generation requires the Firebase Blaze plan with AI Logic enabled on Google Cloud. You can refine and test prompts here anytime."
                    },
                    color = Color(0xFF94A3B8),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
