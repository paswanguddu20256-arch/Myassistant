package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessageEntity
import com.example.ui.AssistantStatus
import com.example.ui.MainViewModel
import com.example.ui.components.JarvisOrb
import com.example.ui.theme.JarvisBlue
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkBackground
import com.example.ui.theme.JarvisDarkBorder
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisDarkSurfaceVariant
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisOrange
import com.example.ui.theme.JarvisPurple
import com.example.ui.theme.JarvisRed

@Composable
fun AssistantScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val status by viewModel.assistantStatus.collectAsState()
    val audioRms by viewModel.audioRms.collectAsState()
    val messages by viewModel.chatMessages.collectAsState()
    val confirmationState by viewModel.confirmationDialog.collectAsState()
    val isFloatingActive by viewModel.isFloatingActive.collectAsState()
    val isWakeWordActive by viewModel.isWakeWordServiceRunning.collectAsState()
    val isWakeWordEnabled by viewModel.isWakeWordEnabled.collectAsState()
    val context = LocalContext.current

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Confirmation Dialog for external actions (WhatsApp message drafting / phone actions)
    if (confirmationState.isOpen) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissPendingAction() },
            title = {
                Text(
                    text = "Action Confirmation",
                    color = JarvisCyan,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = confirmationState.promptMessage,
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Message Draft:\n\"${confirmationState.action?.parameters?.get("message") ?: ""}\"",
                        color = JarvisCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.confirmPendingAction() },
                    modifier = Modifier.testTag("confirm_action_button")
                ) {
                    Text("Confirm & Execute", color = JarvisCyan, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { viewModel.dismissPendingAction() },
                    modifier = Modifier.testTag("dismiss_action_button")
                ) {
                    Text("Cancel", color = JarvisRed)
                }
            },
            containerColor = JarvisDarkSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisDarkBackground)
    ) {
        // Top status header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            when (status) {
                                AssistantStatus.LISTENING -> JarvisCyan
                                AssistantStatus.THINKING -> JarvisPurple
                                AssistantStatus.SPEAKING -> JarvisBlue
                                AssistantStatus.EXECUTING -> JarvisOrange
                                AssistantStatus.IDLE -> JarvisGreen
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "JARVIS CORE 3.8",
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            if (status == AssistantStatus.SPEAKING) {
                IconButton(
                    onClick = { viewModel.stopSpeaking() },
                    modifier = Modifier.testTag("stop_speech_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeOff,
                        contentDescription = "Stop speech",
                        tint = JarvisRed
                    )
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = JarvisDarkSurfaceVariant.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = if (viewModel.preferences.language.startsWith("hi")) "हिन्दी / Hinglish" else "English (India)",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Central Animated Jarvis Voice Orb & Status
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                JarvisOrb(
                    status = status,
                    audioRms = audioRms,
                    onClick = { viewModel.toggleListening() },
                    modifier = Modifier.testTag("jarvis_central_orb")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Status Pill
                val statusText = when (status) {
                    AssistantStatus.LISTENING -> "LISTENING… (बोलिए)"
                    AssistantStatus.THINKING -> "PROCESSING QUERY…"
                    AssistantStatus.SPEAKING -> "SPEAKING RESPONSE…"
                    AssistantStatus.EXECUTING -> "EXECUTING PHONE ACTION…"
                    AssistantStatus.IDLE -> "TAP ORB OR MIC TO SPEAK"
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = JarvisDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, JarvisDarkBorder)
                ) {
                    Text(
                        text = statusText,
                        color = when (status) {
                            AssistantStatus.LISTENING -> JarvisCyan
                            AssistantStatus.THINKING -> JarvisPurple
                            AssistantStatus.SPEAKING -> JarvisBlue
                            AssistantStatus.EXECUTING -> JarvisOrange
                            AssistantStatus.IDLE -> Color(0xFF8B9CB5)
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Floating Screen Assistant Quick Launcher Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = if (isFloatingActive) JarvisGreen else JarvisCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Floating Assistant (Over Apps)",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isFloatingActive) "Active • Drag orb on screen" else "Talk to JARVIS over any app",
                            color = if (isFloatingActive) JarvisGreen else Color(0xFF8B9CB5),
                            fontSize = 10.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { viewModel.triggerUnderstandScreen() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("understand_screen_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = JarvisCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Screen", color = JarvisCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.toggleFloatingAssistant(context, !isFloatingActive)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFloatingActive) JarvisRed.copy(alpha = 0.8f) else JarvisCyan
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("toggle_floating_button")
                    ) {
                        Text(
                            text = if (isFloatingActive) "Stop" else "Float",
                            color = if (isFloatingActive) Color.White else Color(0xFF070B14),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Wake-Word Quick Status / Toggle Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 2.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isWakeWordActive) JarvisCyan else JarvisDarkBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Hearing,
                        contentDescription = null,
                        tint = if (isWakeWordActive) JarvisCyan else Color(0xFF8B9CB5),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Wake Word (\"Hey JARVIS\")",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isWakeWordActive) "Listening for 'Hey JARVIS' / 'JARVIS'" else "Say 'Hey JARVIS' to trigger voice input",
                            color = if (isWakeWordActive) JarvisGreen else Color(0xFF8B9CB5),
                            fontSize = 10.sp
                        )
                    }
                }

                Button(
                    onClick = { viewModel.toggleWakeWordListening(context, !isWakeWordEnabled) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isWakeWordActive) JarvisRed.copy(alpha = 0.8f) else JarvisCyan
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("toggle_wake_word_button")
                ) {
                    Text(
                        text = if (isWakeWordActive) "Stop" else "Listen",
                        color = if (isWakeWordActive) Color.White else Color(0xFF070B14),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Multilingual Prompt Suggestion Chips (Horizontal Scroll)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SuggestionChip(
                label = "📜 Neeche scroll karo",
                onClick = { viewModel.handleUserMessage("JARVIS, neeche scroll karo") }
            )
            SuggestionChip(
                label = "👁️ Screen par kya dikh raha hai?",
                onClick = { viewModel.triggerUnderstandScreen("JARVIS, screen par kya dikh raha hai? Iska vistaar se summary batao.") }
            )
            SuggestionChip(
                label = "📄 Is page ka summary",
                onClick = { viewModel.triggerUnderstandScreen("JARVIS, is page ka summary batao.") }
            )
            SuggestionChip(
                label = "⛔ Emergency Stop",
                onClick = { viewModel.emergencyStop() }
            )
            SuggestionChip(
                label = "YouTube kholo",
                onClick = { viewModel.handleUserMessage("JARVIS, YouTube kholo") }
            )
            SuggestionChip(
                label = "Chrome kholo",
                onClick = { viewModel.handleUserMessage("JARVIS, Chrome kholo") }
            )
            SuggestionChip(
                label = "WhatsApp kholo",
                onClick = { viewModel.handleUserMessage("JARVIS, WhatsApp kholo") }
            )
            SuggestionChip(
                label = "Kesariya search karo",
                onClick = { viewModel.handleUserMessage("YouTube par Kesariya gaana search karo") }
            )
            SuggestionChip(
                label = "WhatsApp kholo",
                onClick = { viewModel.handleUserMessage("WhatsApp kholo") }
            )
            SuggestionChip(
                label = "Installed apps dikhao",
                onClick = { viewModel.handleUserMessage("Mere installed apps dikhao") }
            )
            SuggestionChip(
                label = "Camera kholo",
                onClick = { viewModel.handleUserMessage("Camera kholo") }
            )
            SuggestionChip(
                label = "Aawaz badlo",
                onClick = { viewModel.handleUserMessage("Voice change karo") }
            )
        }

        // Conversation history list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    EmptyAssistantState()
                }
            } else {
                items(messages, key = { it.id }) { msg ->
                    ChatBubble(message = msg)
                }
            }
        }

        // Bottom input bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text(
                        "Command in Hindi, Hinglish, or English…",
                        color = Color(0xFF6B7280),
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisCyan,
                    unfocusedBorderColor = JarvisDarkBorder,
                    focusedContainerColor = JarvisDarkSurface,
                    unfocusedContainerColor = JarvisDarkSurface,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (inputText.isNotBlank()) {
                        viewModel.handleUserMessage(inputText)
                        inputText = ""
                    }
                })
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Mic toggle button
            IconButton(
                onClick = { viewModel.toggleListening() },
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (status == AssistantStatus.LISTENING) JarvisRed else JarvisCyan
                    )
                    .testTag("mic_toggle_button")
            ) {
                Icon(
                    imageVector = if (status == AssistantStatus.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Microphone",
                    tint = if (status == AssistantStatus.LISTENING) Color.White else Color(0xFF070B14)
                )
            }

            // Send text button
            if (inputText.isNotBlank()) {
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = {
                        viewModel.handleUserMessage(inputText)
                        inputText = ""
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(JarvisBlue)
                        .testTag("send_message_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun SuggestionChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = JarvisDarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, JarvisDarkBorder)
    ) {
        Text(
            text = label,
            color = JarvisCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun ChatBubble(message: ChatMessageEntity) {
    val isUser = message.isUser

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(if (isUser) 0.82f else 0.88f)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (isUser) {
                        Brush.linearGradient(listOf(Color(0xFF0A4D68), Color(0xFF088395)))
                    } else {
                        Brush.linearGradient(listOf(JarvisDarkSurfaceVariant, JarvisDarkSurface))
                    }
                )
                .border(
                    1.dp,
                    if (isUser) JarvisCyan.copy(alpha = 0.5f) else JarvisDarkBorder,
                    RoundedCornerShape(16.dp)
                )
                .padding(12.dp)
        ) {
            if (!isUser) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "JARVIS",
                        color = JarvisCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (message.actionType != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (message.actionStatus == "COMPLETED") JarvisGreen.copy(alpha = 0.2f) else JarvisOrange.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "${message.actionType} • ${message.actionStatus}",
                                color = if (message.actionStatus == "COMPLETED") JarvisGreen else JarvisOrange,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            Text(
                text = message.text,
                color = Color.White,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun EmptyAssistantState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Welcome to JARVIS AI",
            color = JarvisCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Aap Hindi, Hinglish, ya English me baat kar sakte hain.\n" +
                    "Try: 'YouTube kholo', 'Arijit Singh ka gaana chalao', ya 'WhatsApp par message bhejne ke liye taiyar karo'.",
            color = Color(0xFF94A3B8),
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 18.sp
        )
    }
}
