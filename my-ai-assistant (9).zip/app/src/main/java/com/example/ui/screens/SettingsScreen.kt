package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.accessibility.JarvisAccessibilityService
import com.example.ui.MainViewModel
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkBackground
import com.example.ui.theme.JarvisDarkBorder
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisOrange
import com.example.ui.theme.JarvisRed

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentLang by remember { mutableStateOf(viewModel.preferences.language) }

    val hasMicPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val isOverlayGranted = Settings.canDrawOverlays(context)
    val isFloatingActive by viewModel.isFloatingActive.collectAsState()

    val isWakeWordActive by viewModel.isWakeWordServiceRunning.collectAsState()
    val isWakeWordEnabled by viewModel.isWakeWordEnabled.collectAsState()
    val isScreenOffListening by viewModel.isScreenOffListeningEnabled.collectAsState()
    val isVoiceResponseEnabled by viewModel.isVoiceResponseEnabled.collectAsState()

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isBatteryExempted = powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true

    val isAccessibilityEnabled = JarvisAccessibilityService.isEnabled(context)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisDarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "JARVIS Settings & Controls",
            color = JarvisCyan,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Wake word, background listening, floating HUD, and device controls",
            color = Color(0xFF8B9CB5),
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 1. EMERGENCY STOP LISTENING NOW
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisRed.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.StopCircle, contentDescription = null, tint = JarvisRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Stop Listening Now",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Sabhi background audio listening, microphone capture, aur wake-word processes ko turant band karein.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.stopListeningNow(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("stop_listening_now_button")
                ) {
                    Text(
                        text = "Stop All Listening Services",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2. WAKE WORD LISTENING ("Hey JARVIS")
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, if (isWakeWordActive) JarvisCyan else JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Hearing, contentDescription = null, tint = JarvisCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Wake-Word Detection",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Switch(
                        checked = isWakeWordEnabled,
                        onCheckedChange = { enable ->
                            viewModel.toggleWakeWordListening(context, enable)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF070B14),
                            checkedTrackColor = JarvisCyan,
                            uncheckedThumbColor = Color(0xFF8B9CB5),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("wake_word_toggle_switch")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "जब चालू होगा, 'Hey JARVIS' या 'JARVIS' बोलने पर अस्सिटेंट तुरंत एक्टिवेट होकर आपकी कमांड सुनेगा.",
                    color = Color(0xFF8B9CB5),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Service Status: ", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Text(
                        text = if (isWakeWordActive) "Active & Listening (Microphone FGS)" else "Stopped",
                        color = if (isWakeWordActive) JarvisGreen else JarvisOrange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3. SCREEN-OFF LISTENING & BATTERY MANAGEMENT
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BatteryAlert, contentDescription = null, tint = JarvisCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Screen-Off Listening",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Switch(
                        checked = isScreenOffListening,
                        onCheckedChange = { enable ->
                            viewModel.toggleScreenOffListening(context, enable)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF070B14),
                            checkedTrackColor = JarvisCyan,
                            uncheckedThumbColor = Color(0xFF8B9CB5),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("screen_off_listening_switch")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "फोन की स्क्रीन बंद होने पर भी वेक-वर्ड लिसनिंग चालू रखने के लिए CPU Partial WakeLock का उपयोग किया जाता है.",
                    color = Color(0xFF8B9CB5),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "⚠️ Android 14+ और OEM Battery Saver (Samsung, Xiaomi, OnePlus) लॉकस्क्रीन पर बैकग्राउंड माइक्रोफ़ोन को डीप-स्लीप में डाल सकते हैं. सुचारू रूप से चलाने के लिए 'Battery Optimization' डिसेबल करना आवश्यक है.",
                    color = JarvisOrange,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isBatteryExempted) "Battery Optimization: Unrestricted" else "Battery Optimization: Active",
                            color = if (isBatteryExempted) JarvisGreen else JarvisOrange,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isBatteryExempted) "Background CPU sleep exempt" else "OS may terminate audio in deep sleep",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(fallback)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("battery_optimization_button")
                    ) {
                        Text(
                            text = if (isBatteryExempted) "Exempted" else "Exempt",
                            color = JarvisCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 4. FLOATING SCREEN ASSISTANT
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Layers, contentDescription = null, tint = JarvisCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Floating Screen Assistant",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Aap kisi bhi app me rehte hue movable orb se JARVIS panel open kar sakte hain aur 'Understand My Screen' se current page ka visual summary le sakte hain.",
                    color = Color(0xFF8B9CB5),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isOverlayGranted) "Overlay Permission Granted" else "Overlay Permission Needed",
                            color = if (isOverlayGranted) JarvisGreen else JarvisOrange,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isFloatingActive) "Floating Assistant is running" else "Assistant is stopped",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.toggleFloatingAssistant(context, !isFloatingActive)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFloatingActive) JarvisRed else JarvisCyan
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("settings_toggle_floating_button")
                    ) {
                        Text(
                            text = if (isFloatingActive) "Stop" else "Enable",
                            color = if (isFloatingActive) Color.White else Color(0xFF070B14),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                if (!isOverlayGranted) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("open_overlay_settings_button")
                    ) {
                        Text(
                            text = "Open 'Display over other apps' Settings",
                            color = JarvisCyan,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 5. ACCESSIBILITY SERVICE (FOR VOICE SCROLLING & NAVIGATION)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Accessibility, contentDescription = null, tint = JarvisCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "JARVIS Accessibility Service",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "वॉइस कमांड द्वारा फोन पर ऑटोमेशन जैसे 'JARVIS, neeche scroll karo', 'upar scroll karo' और 'back jao' को निष्पादित करने के लिए एक्सेसिबिलिटी सर्विस का उपयोग होता है.",
                    color = Color(0xFF8B9CB5),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAccessibilityEnabled) "Service Active" else "Service Disabled",
                        color = if (isAccessibilityEnabled) JarvisGreen else JarvisOrange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("open_accessibility_settings_button")
                    ) {
                        Text(
                            text = if (isAccessibilityEnabled) "Settings" else "Enable in Settings",
                            color = JarvisCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 6. VOICE RESPONSES (TTS) & LANGUAGE
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = JarvisCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Voice Responses (Speech)",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Switch(
                        checked = isVoiceResponseEnabled,
                        onCheckedChange = { enable ->
                            viewModel.toggleVoiceResponse(enable)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF070B14),
                            checkedTrackColor = JarvisCyan,
                            uncheckedThumbColor = Color(0xFF8B9CB5),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("voice_response_toggle_switch")
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isVoiceResponseEnabled) "JARVIS aawaz me bolkar jawab dega." else "Kewal text message aayega, aawaz band rahegi.",
                    color = Color(0xFF8B9CB5),
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = JarvisCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Preferred Language",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val isHindi = currentLang.startsWith("hi")
                    Surface(
                        onClick = {
                            currentLang = "hi_IN"
                            viewModel.setLanguage("hi_IN")
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isHindi) JarvisCyan else Color(0xFF162238),
                        modifier = Modifier.weight(1f).testTag("lang_hindi_button")
                    ) {
                        Text(
                            text = "हिन्दी / Hinglish",
                            color = if (isHindi) Color(0xFF070B14) else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp)
                        )
                    }

                    Surface(
                        onClick = {
                            currentLang = "en_IN"
                            viewModel.setLanguage("en_IN")
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (!isHindi) JarvisCyan else Color(0xFF162238),
                        modifier = Modifier.weight(1f).testTag("lang_english_button")
                    ) {
                        Text(
                            text = "English (India)",
                            color = if (!isHindi) Color(0xFF070B14) else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 7. SYSTEM STATUS & PERMISSIONS VERIFICATION
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "System Status & Permissions",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                StatusRow(
                    label = "Microphone Permission",
                    statusText = if (hasMicPermission) "Granted" else "Tap Orb to Grant",
                    isPass = hasMicPermission
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "Wake Word Background Service",
                    statusText = if (isWakeWordActive) "Active (Microphone FGS)" else "Stopped",
                    isPass = isWakeWordActive
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "Display Over Other Apps (Overlay)",
                    statusText = if (isOverlayGranted) "Active" else "Permission Required",
                    isPass = isOverlayGranted
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "Accessibility Service (Scrolling)",
                    statusText = if (isAccessibilityEnabled) "Active" else "Disabled in Settings",
                    isPass = isAccessibilityEnabled
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "Screen Understanding (MediaProjection)",
                    statusText = "Ready with User Consent",
                    isPass = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "Battery Optimization",
                    statusText = if (isBatteryExempted) "Exempted (Deep Sleep OK)" else "Default Optimization",
                    isPass = isBatteryExempted
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "AI Logic / Gemini Connectivity",
                    statusText = "App Check Ready",
                    isPass = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                StatusRow(
                    label = "Text-to-Speech Engine",
                    statusText = "Device TTS Connected",
                    isPass = true
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 8. DATA STORAGE & CLEAR HISTORY
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Local Data Storage",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Conversation history and progress records are saved locally in private device SQLite storage.",
                    color = Color(0xFF8B9CB5),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.clearHistory() },
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisRed.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("clear_history_button")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = JarvisRed)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Clear Conversation History",
                        color = JarvisRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 9. PRIVACY & SECURITY STATEMENT
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, JarvisDarkBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = JarvisCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Privacy & Security Assurances",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• Transparent Wake Word: Audio is only monitored for the keyword 'Hey JARVIS' / 'JARVIS' when enabled by you.\n" +
                            "• User Consent Screen Capture: Screen content is only captured when you explicitly tap 'Understand My Screen' and approve the Android system prompt.\n" +
                            "• User Confirmation: Sensitive actions such as sending messages always ask for your explicit confirmation.\n" +
                            "• Zero Embedded Secrets: API keys are securely loaded through BuildConfig at runtime.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 10. ABOUT & VERSION
        Text(
            text = "JARVIS AI Assistant • Version 1.0 (Build 1)\nWake Word Engine • MediaProjection Vision • Accessibility Navigation",
            color = Color(0xFF64748B),
            fontSize = 11.sp,
            lineHeight = 16.sp
        )
    }
}

@Composable
fun StatusRow(
    label: String,
    statusText: String,
    isPass: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xFFE2E8F0), fontSize = 13.sp)
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isPass) JarvisGreen.copy(alpha = 0.2f) else JarvisOrange.copy(alpha = 0.2f)
        ) {
            Text(
                text = statusText,
                color = if (isPass) JarvisGreen else JarvisOrange,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
        }
    }
}
