package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color(0xFF00363A),
    primaryContainer = Color(0xFF004F54),
    onPrimaryContainer = Color(0xFF70F5FF),
    secondary = JarvisBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF003F8A),
    onSecondaryContainer = Color(0xFFD1E4FF),
    tertiary = JarvisTeal,
    onTertiary = Color.Black,
    background = JarvisDarkBackground,
    onBackground = JarvisDarkTextPrimary,
    surface = JarvisDarkSurface,
    onSurface = JarvisDarkTextPrimary,
    surfaceVariant = JarvisDarkSurfaceVariant,
    onSurfaceVariant = JarvisDarkTextSecondary,
    outline = JarvisDarkBorder,
    error = JarvisRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = JarvisLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = Color(0xFF001B3E),
    secondary = JarvisTeal,
    onSecondary = Color.Black,
    tertiary = JarvisPurple,
    background = JarvisLightBackground,
    onBackground = JarvisLightTextPrimary,
    surface = JarvisLightSurface,
    onSurface = JarvisLightTextPrimary,
    surfaceVariant = JarvisLightSurfaceVariant,
    onSurfaceVariant = JarvisLightTextSecondary,
    outline = Color(0xFFB0C4DE),
    error = JarvisRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Default to Jarvis futuristic theme for distinct aesthetics
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
