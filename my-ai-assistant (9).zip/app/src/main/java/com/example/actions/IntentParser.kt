package com.example.actions

import java.util.Locale

object IntentParser {

    fun parse(input: String): SmartAction {
        val trimmed = input.trim()
        var stripped = trimmed
        val wakePrefixes = listOf(
            "hey jarvis,", "hey jarvis", "jarvis,", "jarvis",
            "हे जार्विस,", "हे जार्विस", "जार्विस,", "जार्विस",
            "ok jarvis,", "ok jarvis", "hello jarvis,", "hello jarvis"
        )
        for (wp in wakePrefixes) {
            if (stripped.lowercase(Locale.ROOT).startsWith(wp)) {
                stripped = stripped.substring(wp.length).trim(' ', ',', ':', '!')
                break
            }
        }

        val effective = if (stripped.isNotBlank()) stripped else trimmed
        val lower = effective.lowercase(Locale.ROOT)

        // 0. Emergency Stop
        // Examples: "Emergency stop", "JARVIS stop", "ruko", "cancel karo", "sab band karo"
        if (lower.contains("emergency stop") || lower.contains("stop") || lower.contains("ruko") || lower.contains("cancel karo") || lower.contains("band karo")) {
            return SmartAction(
                type = ActionType.EMERGENCY_STOP,
                title = "Emergency Stop",
                description = "सभी एक्टिविटी, वॉइस और पेंडिंग एक्शन्स तुरंत रोके जा रहे हैं.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        // 0.2. Scrolling & Navigation Actions (Accessibility Service)
        if (isScrollDownCommand(lower)) {
            return SmartAction(
                type = ActionType.SCROLL_DOWN,
                title = "Scroll Down",
                description = "स्क्रीन को नीचे स्क्रॉल किया जा रहा है.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        if (isScrollUpCommand(lower)) {
            return SmartAction(
                type = ActionType.SCROLL_UP,
                title = "Scroll Up",
                description = "स्क्रीन को ऊपर स्क्रॉल किया जा रहा है.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        if (isGoBackCommand(lower)) {
            return SmartAction(
                type = ActionType.GO_BACK,
                title = "Go Back",
                description = "पिछली स्क्रीन पर वापस जाया जा रहा है.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        if (isGoHomeCommand(lower)) {
            return SmartAction(
                type = ActionType.GO_HOME,
                title = "Go Home",
                description = "फोन की होम स्क्रीन खोली जा रही है.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        // 0.5. Understand My Screen
        // Examples: "JARVIS, screen par kya likha hai?", "screen par kya dikh raha hai?", "Is page ka summary batao", "Mujhe yahan kya karna hai?", "Is error ko samjhao", "Understand my screen"
        if (isScreenUnderstandingCommand(lower)) {
            return SmartAction(
                type = ActionType.UNDERSTAND_SCREEN,
                title = "Understand Screen",
                description = "वर्तमान स्क्रीन का विश्लेषण करके आपको मार्गदर्शन देंगे.",
                parameters = mapOf("query" to effective),
                requiresConfirmation = false
            )
        }

        // 1. YouTube specific commands
        // Examples: "YouTube par Arijit Singh ka gaana chalao", "Kesariya search karo", "YouTube par relaxing music dhoondo", "play kesariya on youtube"
        if (isYouTubeSearchCommand(lower)) {
            val query = extractYouTubeQuery(lower, trimmed)
            return SmartAction(
                type = ActionType.SEARCH_YOUTUBE,
                title = "YouTube Music / Video Search",
                description = "YouTube par search karenge: \"$query\"",
                parameters = mapOf("query" to query),
                requiresConfirmation = false
            )
        }

        // 2. Open App commands
        // Examples: "YouTube kholo", "WhatsApp kholo", "Instagram kholo", "Chrome kholo", "Camera kholo", "Phone ki settings kholo"
        val detectedApp = detectAppToLaunch(lower)
        if (detectedApp != null) {
            val (appName, pkgName) = detectedApp
            if (appName.equals("Camera", ignoreCase = true)) {
                return SmartAction(
                    type = ActionType.OPEN_CAMERA,
                    title = "Open Camera",
                    description = "Phone ka camera open karenge",
                    parameters = emptyMap(),
                    requiresConfirmation = false
                )
            }
            if (appName.equals("Settings", ignoreCase = true)) {
                return SmartAction(
                    type = ActionType.OPEN_SETTINGS,
                    title = "Phone Settings",
                    description = "Phone ki main settings open karenge",
                    parameters = emptyMap(),
                    requiresConfirmation = false
                )
            }
            return SmartAction(
                type = ActionType.OPEN_APP,
                title = "Launch $appName",
                description = "$appName app open karenge",
                parameters = mapOf("appName" to appName, "packageName" to (pkgName ?: "")),
                requiresConfirmation = false
            )
        }

        // 3. WhatsApp and Messaging commands
        // Examples: "WhatsApp par message bhejne ke liye taiyar karo", "Mere dost ko message likhne mein madad karo", "Draft message to hello"
        if (isMessageDraftCommand(lower)) {
            val draft = extractMessageDraft(lower, trimmed)
            return SmartAction(
                type = ActionType.PREPARE_MESSAGE,
                title = "Prepare WhatsApp Message",
                description = "Message draft तैयार करेंगे और भेजने से पहले आपसे पुष्टि लेंगे.",
                parameters = mapOf("message" to draft),
                requiresConfirmation = true // Safety confirmation as mandated
            )
        }

        // 4. Show installed apps
        // Examples: "Mere installed apps dikhao", "installed apps list", "show my apps"
        if (lower.contains("installed apps") || lower.contains("apps dikhao") || lower.contains("mere apps")) {
            return SmartAction(
                type = ActionType.SHOW_INSTALLED_APPS,
                title = "Show Installed Apps",
                description = "Phone me available sabhi launchable apps ki list dikha rahe hain.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        // 5. Image Generation
        // Examples: "Ek cinematic image banao...", "Generate image of...", "Photo create karo"
        if (isImageGenerationCommand(lower)) {
            val prompt = extractImagePrompt(lower, trimmed)
            return SmartAction(
                type = ActionType.GENERATE_IMAGE,
                title = "AI Image Generator",
                description = "Image prompt: \"$prompt\"",
                parameters = mapOf("prompt" to prompt),
                requiresConfirmation = false
            )
        }

        // 6. Voice Studio / Voice Change
        if (lower.contains("voice change") || lower.contains("aawaz badlo") || lower.contains("voice studio") || lower.contains("change voice")) {
            return SmartAction(
                type = ActionType.CHANGE_ASSISTANT_VOICE,
                title = "Voice Studio",
                description = "Voice Studio me assistant ki aawaz aur speed badlenge.",
                parameters = emptyMap(),
                requiresConfirmation = false
            )
        }

        // 7. General AI Question / Conversation fallback
        return SmartAction(
            type = ActionType.ANSWER_QUESTION,
            title = "JARVIS AI Conversation",
            description = "Natural language response in Hindi/Hinglish/English",
            parameters = mapOf("prompt" to trimmed),
            requiresConfirmation = false
        )
    }

    private fun isYouTubeSearchCommand(lower: String): Boolean {
        if (lower.startsWith("youtube kholo") || lower == "open youtube") return false
        val triggers = listOf(
            "youtube par", "youtube me", "gaana chalao", "play on youtube",
            "search karo", "youtube pe", "dhoondo", "song play", "music chalao"
        )
        return triggers.any { lower.contains(it) } || (lower.contains("youtube") && lower.contains("search"))
    }

    private fun extractYouTubeQuery(lower: String, original: String): String {
        var clean = original
        val prefixesToRemove = listOf(
            "youtube par", "youtube me", "youtube pe", "search on youtube",
            "play on youtube", "play", "search", "dhoondo", "chalao"
        )
        val suffixesToRemove = listOf(
            "ka gaana chalao", "gaana chalao", "song chalao", "search karo",
            "dhoondo", "play karo", "lagao", "sunao", "chala do"
        )

        for (suffix in suffixesToRemove) {
            val idx = clean.lowercase().lastIndexOf(suffix)
            if (idx != -1) {
                clean = clean.substring(0, idx).trim()
            }
        }
        for (prefix in prefixesToRemove) {
            if (clean.lowercase().startsWith(prefix)) {
                clean = clean.substring(prefix.length).trim()
            }
        }
        return if (clean.isBlank()) "Top Indian Music Hits" else clean
    }

    private fun detectAppToLaunch(lower: String): Pair<String, String?>? {
        val launchVerbs = listOf("kholo", "open", "launch", "chalao", "start")
        val isLaunchIntent = launchVerbs.any { lower.contains(it) }

        if (!isLaunchIntent && !lower.endsWith("kholo")) return null

        return when {
            lower.contains("youtube") -> "YouTube" to "com.google.android.youtube"
            lower.contains("whatsapp") -> "WhatsApp" to "com.whatsapp"
            lower.contains("chrome") -> "Google Chrome" to "com.android.chrome"
            lower.contains("instagram") -> "Instagram" to "com.instagram.android"
            lower.contains("camera") -> "Camera" to null
            lower.contains("setting") -> "Settings" to null
            lower.contains("map") -> "Google Maps" to "com.google.android.apps.maps"
            lower.contains("gmail") -> "Gmail" to "com.google.android.gm"
            else -> null
        }
    }

    private fun isMessageDraftCommand(lower: String): Boolean {
        return lower.contains("message") || lower.contains("sandesh") || lower.contains("chat")
    }

    private fun extractMessageDraft(lower: String, original: String): String {
        val triggers = listOf(
            "message likhne mein madad karo",
            "message bhejne ke liye taiyar karo",
            "message draft karo",
            "prepare message",
            "write message"
        )
        for (t in triggers) {
            val idx = original.lowercase().indexOf(t)
            if (idx != -1 && idx + t.length < original.length) {
                val after = original.substring(idx + t.length).trim(' ', ':', '-', '"')
                if (after.isNotBlank()) return after
            }
        }
        return "Namaste! Yeh JARVIS AI Assistant ke dwara taiyar kiya gaya sandesh hai."
    }

    private fun isImageGenerationCommand(lower: String): Boolean {
        return lower.contains("image banao") || lower.contains("photo banao") ||
                lower.contains("generate image") || lower.contains("picture banao") ||
                lower.contains("tasveer banao") || lower.contains("draw") ||
                lower.contains("create an image")
    }

    private fun extractImagePrompt(lower: String, original: String): String {
        val triggers = listOf(
            "image banao jismein", "image banao jisme", "image banao",
            "photo banao", "generate an image of", "generate image of", "generate image"
        )
        for (t in triggers) {
            val idx = original.lowercase().indexOf(t)
            if (idx != -1) {
                val after = original.substring(idx + t.length).trim(' ', ':', '-')
                if (after.isNotBlank()) return after
            }
        }
        return original
    }

    private fun isScreenUnderstandingCommand(lower: String): Boolean {
        val triggers = listOf(
            "screen par kya likha hai",
            "screen par kya dikh raha hai",
            "screen par kya dikhai de raha hai",
            "screen par kya hai",
            "screen samjhao",
            "is page ka summary",
            "page ka summary",
            "page samjhao",
            "is error ko samjhao",
            "error samjhao",
            "mujhe yahan kya karna hai",
            "understand my screen",
            "read my screen",
            "read screen",
            "screen padho",
            "screen dekho",
            "screen analyze karo",
            "analyze screen"
        )
        return triggers.any { lower.contains(it) } || (lower.contains("screen") && (lower.contains("summary") || lower.contains("kya hai") || lower.contains("kya dikh") || lower.contains("batao")))
    }

    private fun isScrollDownCommand(lower: String): Boolean {
        val triggers = listOf(
            "neeche scroll karo", "neeche scroll", "scroll down",
            "page neeche karo", "neeche jao", "down scroll", "down scroll karo",
            "niche scroll"
        )
        return triggers.any { lower.contains(it) }
    }

    private fun isScrollUpCommand(lower: String): Boolean {
        val triggers = listOf(
            "upar scroll karo", "upar scroll", "scroll up",
            "page upar karo", "upar jao", "up scroll", "up scroll karo"
        )
        return triggers.any { lower.contains(it) }
    }

    private fun isGoBackCommand(lower: String): Boolean {
        val triggers = listOf("back jao", "go back", "piche jao", "peeche jao", "wapas jao", "back karo")
        return triggers.any { lower.contains(it) }
    }

    private fun isGoHomeCommand(lower: String): Boolean {
        val triggers = listOf("home jao", "go home", "home screen kholo", "home screen jao", "home par jao")
        return triggers.any { lower.contains(it) }
    }
}
