package com.example.actions

enum class ActionType {
    OPEN_APP,
    SEARCH_YOUTUBE,
    PREPARE_MESSAGE,
    GENERATE_IMAGE,
    OPEN_SETTINGS,
    OPEN_CAMERA,
    SHOW_INSTALLED_APPS,
    CHANGE_ASSISTANT_VOICE,
    UNDERSTAND_SCREEN,
    SCROLL_DOWN,
    SCROLL_UP,
    GO_BACK,
    GO_HOME,
    EMERGENCY_STOP,
    ANSWER_QUESTION
}

enum class ActionExecutionStatus {
    PENDING,
    WAITING_FOR_CONFIRMATION,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class SmartAction(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: ActionType,
    val title: String,
    val description: String,
    val parameters: Map<String, String> = emptyMap(),
    val requiresConfirmation: Boolean = false,
    var status: ActionExecutionStatus = ActionExecutionStatus.PENDING,
    var resultMessage: String? = null,
    var errorDetails: String? = null
)
