package com.example.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log

data class InstalledAppInfo(
    val appName: String,
    val packageName: String
)

sealed interface ExecutionResult {
    data class Success(val message: String, val details: String? = null) : ExecutionResult
    data class Failure(val error: String, val suggestion: String? = null) : ExecutionResult
    data class NeedsConfirmation(val message: String, val pendingPayload: Map<String, String>) : ExecutionResult
}

object SmartActionExecutor {
    private const val TAG = "SmartActionExecutor"

    fun execute(context: Context, action: SmartAction, userConfirmed: Boolean = false): ExecutionResult {
        Log.d(TAG, "Executing action: ${action.type}, confirmed: $userConfirmed")

        if (action.requiresConfirmation && !userConfirmed) {
            return ExecutionResult.NeedsConfirmation(
                message = "क्या आप यह एक्शन शुरू करना चाहते हैं? पुष्टि करें: ${action.description}",
                pendingPayload = action.parameters
            )
        }

        return try {
            when (action.type) {
                ActionType.OPEN_APP -> launchApp(context, action.parameters["packageName"], action.parameters["appName"])
                ActionType.SEARCH_YOUTUBE -> searchYouTube(context, action.parameters["query"] ?: "Arijit Singh")
                ActionType.PREPARE_MESSAGE -> prepareWhatsAppMessage(context, action.parameters["message"] ?: "")
                ActionType.OPEN_SETTINGS -> openSettings(context)
                ActionType.OPEN_CAMERA -> openCamera(context)
                ActionType.SHOW_INSTALLED_APPS -> {
                    val apps = getInstalledLaunchableApps(context)
                    ExecutionResult.Success(
                        message = "Phone me ${apps.size} launchable apps paye gaye.",
                        details = apps.take(15).joinToString(", ") { it.appName }
                    )
                }
                ActionType.GENERATE_IMAGE -> {
                    ExecutionResult.Success(
                        message = "Image Generator studio par redirect kiya gaya.",
                        details = action.parameters["prompt"]
                    )
                }
                ActionType.CHANGE_ASSISTANT_VOICE -> {
                    ExecutionResult.Success(
                        message = "Voice Studio screen par le jaaya gaya.",
                        details = "Voice preferences"
                    )
                }
                ActionType.ANSWER_QUESTION -> {
                    ExecutionResult.Success(
                        message = action.resultMessage ?: "Response ready.",
                        details = null
                    )
                }
                ActionType.UNDERSTAND_SCREEN -> {
                    ExecutionResult.Success(
                        message = "Screen understanding triggered.",
                        details = action.parameters["query"]
                    )
                }
                ActionType.SCROLL_DOWN -> {
                    if (com.example.accessibility.JarvisAccessibilityService.isEnabled(context)) {
                        val ok = com.example.accessibility.JarvisAccessibilityService.scrollDown()
                        if (ok) {
                            ExecutionResult.Success(message = "Screen safaltapoorvak neeche scroll ki gayi.")
                        } else {
                            ExecutionResult.Failure(
                                error = "Screen neeche scroll nahi ho saki.",
                                suggestion = "Kripya sunishchit karein ki app me scrollable content ho."
                            )
                        }
                    } else {
                        ExecutionResult.Failure(
                            error = "JARVIS Accessibility Service enabled nahi hai.",
                            suggestion = "Phone Settings > Accessibility me jakar 'JARVIS Accessibility Service' ko chalu karein."
                        )
                    }
                }
                ActionType.SCROLL_UP -> {
                    if (com.example.accessibility.JarvisAccessibilityService.isEnabled(context)) {
                        val ok = com.example.accessibility.JarvisAccessibilityService.scrollUp()
                        if (ok) {
                            ExecutionResult.Success(message = "Screen safaltapoorvak upar scroll ki gayi.")
                        } else {
                            ExecutionResult.Failure(
                                error = "Screen upar scroll nahi ho saki.",
                                suggestion = "Kripya sunishchit karein ki app me scrollable content ho."
                            )
                        }
                    } else {
                        ExecutionResult.Failure(
                            error = "JARVIS Accessibility Service enabled nahi hai.",
                            suggestion = "Phone Settings > Accessibility me jakar 'JARVIS Accessibility Service' ko chalu karein."
                        )
                    }
                }
                ActionType.GO_BACK -> {
                    if (com.example.accessibility.JarvisAccessibilityService.isEnabled(context)) {
                        com.example.accessibility.JarvisAccessibilityService.goBack()
                        ExecutionResult.Success(message = "Pichli screen par wapas le jaya gaya.")
                    } else {
                        ExecutionResult.Failure(
                            error = "Accessibility service required.",
                            suggestion = "Turn on 'JARVIS Accessibility Service' in Settings."
                        )
                    }
                }
                ActionType.GO_HOME -> {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(homeIntent)
                    ExecutionResult.Success(message = "Home screen par switch kiya gaya.")
                }
                ActionType.EMERGENCY_STOP -> {
                    ExecutionResult.Success(
                        message = "Emergency stop executed.",
                        details = null
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Execution error for ${action.type}", e)
            ExecutionResult.Failure(
                error = e.localizedMessage ?: "Action execution failed.",
                suggestion = "Please check device permissions or verify if the app is installed."
            )
        }
    }

    fun launchApp(context: Context, packageName: String?, appName: String?): ExecutionResult {
        val pm = context.packageManager

        // 1. Try by package name if known
        if (!packageName.isNullOrBlank()) {
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ExecutionResult.Success(message = "$appName app safaltapoorvak open kiya gaya.")
            }
        }

        // 2. Try finding app by label among launcher apps
        val queryIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveList = pm.queryIntentActivities(queryIntent, 0)
        val matched = resolveList.firstOrNull {
            val label = it.loadLabel(pm).toString()
            appName != null && label.contains(appName, ignoreCase = true)
        }

        if (matched != null) {
            val pkg = matched.activityInfo.packageName
            val intent = pm.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return ExecutionResult.Success(message = "${matched.loadLabel(pm)} open kiya gaya.")
            }
        }

        return ExecutionResult.Failure(
            error = "App '$appName' is phone me installed nahi mila.",
            suggestion = "Aap Play Store se '$appName' install kar sakte hain."
        )
    }

    fun searchYouTube(context: Context, query: String): ExecutionResult {
        val encodedQuery = Uri.encode(query)
        // Try native YouTube intent first
        val appIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        val pm = context.packageManager
        if (appIntent.resolveActivity(pm) != null) {
            context.startActivity(appIntent)
            return ExecutionResult.Success(
                message = "YouTube par \"$query\" search khola gaya.",
                details = "Note: Gaana bajane ke liye YouTube par video select karein."
            )
        }

        // Fallback to browser search URL
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encodedQuery")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(webIntent)
        return ExecutionResult.Success(
            message = "Browser me YouTube search \"$query\" open kiya gaya.",
            details = "Gaana play karne ke liye video tap karein."
        )
    }

    fun prepareWhatsAppMessage(context: Context, text: String): ExecutionResult {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            setPackage("com.whatsapp")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        val pm = context.packageManager
        if (sendIntent.resolveActivity(pm) != null) {
            context.startActivity(sendIntent)
            return ExecutionResult.Success(
                message = "WhatsApp khola gaya aur aapka message draft taiyar hai.",
                details = "Bhejne ke liye contact chunein aur send tap karein."
            )
        }

        // Generic sharing chooser fallback
        val chooser = Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }, "Send message via").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(chooser)
        return ExecutionResult.Success(
            message = "Messaging apps chooser khola gaya.",
            details = "WhatsApp install nahi mila, anya messaging app select karein."
        )
    }

    fun openSettings(context: Context): ExecutionResult {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return ExecutionResult.Success(message = "Phone settings open kiya gaya.")
    }

    fun openCamera(context: Context): ExecutionResult {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val pm = context.packageManager
        if (intent.resolveActivity(pm) != null) {
            context.startActivity(intent)
            return ExecutionResult.Success(message = "Camera open kiya gaya.")
        }
        return ExecutionResult.Failure(error = "Camera app launch karne me samasya aayi.")
    }

    fun getInstalledLaunchableApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val queryIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveList = pm.queryIntentActivities(queryIntent, 0)
        return resolveList.map {
            InstalledAppInfo(
                appName = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName
            )
        }.sortedBy { it.appName }
    }
}
