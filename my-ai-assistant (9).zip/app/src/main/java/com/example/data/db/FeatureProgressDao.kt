package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.FeatureProgressEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FeatureProgressDao {
    @Query("SELECT * FROM feature_progress ORDER BY featureKey ASC")
    fun getAllProgressFlow(): Flow<List<FeatureProgressEntity>>

    @Query("SELECT * FROM feature_progress WHERE featureKey = :key LIMIT 1")
    suspend fun getProgressByKey(key: String): FeatureProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(progress: FeatureProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<FeatureProgressEntity>)

    @Query("UPDATE feature_progress SET testStatus = :testStatus, errorDetails = :errorDetails, lastUpdated = :lastUpdated WHERE featureKey = :key")
    suspend fun updateTestStatus(key: String, testStatus: String, errorDetails: String?, lastUpdated: Long = System.currentTimeMillis())
}
