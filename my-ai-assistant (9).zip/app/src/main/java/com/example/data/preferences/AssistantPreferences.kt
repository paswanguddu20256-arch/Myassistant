package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class AssistantPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("assistant_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LANGUAGE = "pref_language"
        private const val KEY_VOICE_NAME = "pref_voice_name"
        private const val KEY_SPEECH_RATE = "pref_speech_rate"
        private const val KEY_SPEECH_PITCH = "pref_speech_pitch"
        private const val KEY_DARK_THEME = "pref_dark_theme"
        private const val KEY_FLOATING_ASSISTANT = "pref_floating_assistant"
        private const val KEY_WAKE_WORD_LISTENING = "pref_wake_word_listening"
        private const val KEY_SCREEN_OFF_LISTENING = "pref_screen_off_listening"
        private const val KEY_VOICE_RESPONSE_ENABLED = "pref_voice_response_enabled"
    }

    var isWakeWordListeningEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_WORD_LISTENING, false)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_WORD_LISTENING, value).apply()

    var isScreenOffListeningEnabled: Boolean
        get() = prefs.getBoolean(KEY_SCREEN_OFF_LISTENING, false)
        set(value) = prefs.edit().putBoolean(KEY_SCREEN_OFF_LISTENING, value).apply()

    var isVoiceResponseEnabled: Boolean
        get() = prefs.getBoolean(KEY_VOICE_RESPONSE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_VOICE_RESPONSE_ENABLED, value).apply()

    var isFloatingAssistantEnabled: Boolean
        get() = prefs.getBoolean(KEY_FLOATING_ASSISTANT, false)
        set(value) = prefs.edit().putBoolean(KEY_FLOATING_ASSISTANT, value).apply()

    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "hi_IN") ?: "hi_IN"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var voiceName: String?
        get() = prefs.getString(KEY_VOICE_NAME, null)
        set(value) = prefs.edit().putString(KEY_VOICE_NAME, value).apply()

    var speechRate: Float
        get() = prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_RATE, value).apply()

    var speechPitch: Float
        get() = prefs.getFloat(KEY_SPEECH_PITCH, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_PITCH, value).apply()

    var isDarkTheme: Boolean
        get() = prefs.getBoolean(KEY_DARK_THEME, true)
        set(value) = prefs.edit().putBoolean(KEY_DARK_THEME, value).apply()
}
