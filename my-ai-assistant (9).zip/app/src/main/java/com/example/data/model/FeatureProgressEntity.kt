package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "feature_progress")
data class FeatureProgressEntity(
    @PrimaryKey
    val featureKey: String,
    val title: String,
    val description: String,
    val implementationStatus: String, // "Implemented", "In Progress", "Not Started"
    val testStatus: String, // "Tested Successfully", "Implemented, Not Tested", "Blocked", "Failed"
    val lastUpdated: Long = System.currentTimeMillis(),
    val knownLimitations: String,
    val requiredSetup: String,
    val errorDetails: String? = null
)
