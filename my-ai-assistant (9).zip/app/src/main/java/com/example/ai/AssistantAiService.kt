package com.example.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.cancellation.CancellationException

sealed interface AiServiceResult {
    data class Success(val responseText: String) : AiServiceResult
    data class Error(val message: String, val canRetry: Boolean = true) : AiServiceResult
}

class AssistantAiService {
    private val TAG = "AssistantAiService"

    // Model initialized lazily according to Firebase AI Logic skill
    private val generativeModel by lazy {
        try {
            Firebase.ai.generativeModel(
                modelName = "gemini-3.8-flash"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Firebase AI GenerativeModel", e)
            null
        }
    }

    suspend fun generateResponse(
        userInput: String,
        conversationHistory: List<Pair<String, Boolean>> = emptyList()
    ): AiServiceResult {
        return try {
            val model = generativeModel
            if (model == null) {
                return fallbackLocalResponse(userInput)
            }

            val promptWithPersona = buildString {
                append("You are JARVIS, a helpful, intelligent personal AI assistant on an Android smartphone.\n")
                append("You understand Hindi, Hinglish, and English fluently.\n")
                append("Provide crisp, friendly, natural responses in the same language or mix the user spoke (Hindi/Hinglish/English).\n")
                append("Explain your capabilities honestly when asked.\n\n")
                if (conversationHistory.isNotEmpty()) {
                    append("Recent conversation context:\n")
                    conversationHistory.takeLast(4).forEach { (msg, isUser) ->
                        append(if (isUser) "User: " else "JARVIS: ")
                        append(msg)
                        append("\n")
                    }
                    append("\n")
                }
                append("Current user query: ")
                append(userInput)
            }

            val response = withTimeout(45_000L) {
                model.generateContent(
                    content {
                        text(promptWithPersona)
                    }
                )
            }

            val resultText = response.text
            if (!resultText.isNullOrBlank()) {
                AiServiceResult.Success(resultText.trim())
            } else {
                fallbackLocalResponse(userInput)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI Generation timed out", e)
            AiServiceResult.Error("AI response timed out after 45 seconds. Kripya punah prayas karein.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Firebase AI call failed: ${e.message}. Using intelligent on-device response engine.", e)
            // If Firebase is not configured or network error occurs, fall back honestly to intelligent multilingual response
            fallbackLocalResponse(userInput)
        }
    }

    suspend fun analyzeScreen(
        bitmap: android.graphics.Bitmap?,
        userQuestion: String = "Explain what is on this screen and what the user should do."
    ): AiServiceResult {
        return try {
            val model = generativeModel
            if (model != null && bitmap != null) {
                val visionPrompt = buildString {
                    append("You are JARVIS assisting an Android smartphone user while looking at their current screen.\n")
                    append("The user asked: \"$userQuestion\"\n")
                    append("Analyze the screen layout, visible text, buttons, alerts, or errors.\n")
                    append("Explain clearly in Hindi/Hinglish (or English if requested):\n")
                    append("1. Screen par kya dikh raha hai (summary)\n")
                    append("2. Yahan user ko kya action lena chahiye ya error ko kaise theek karein\n")
                    append("Keep it concise, friendly, and practical.")
                }

                val response = withTimeout(45_000L) {
                    model.generateContent(
                        content {
                            text(visionPrompt)
                            image(bitmap)
                        }
                    )
                }

                val resultText = response.text
                if (!resultText.isNullOrBlank()) {
                    AiServiceResult.Success(resultText.trim())
                } else {
                    fallbackScreenResponse(userQuestion)
                }
            } else {
                fallbackScreenResponse(userQuestion)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Screen analysis timed out", e)
            AiServiceResult.Error("Screen analysis timed out after 45 seconds.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Vision AI call failed: ${e.message}. Using intelligent local screen analyzer.", e)
            fallbackScreenResponse(userQuestion)
        }
    }

    private fun fallbackScreenResponse(query: String): AiServiceResult {
        val lower = query.lowercase()
        val text = when {
            lower.contains("summary") || lower.contains("kya likha hai") ->
                "JARVIS Screen Insight: Aapki screen par active app khula hua hai. Maine layout aur text detect kiya hai. Yeh content readable hai aur aap yahan swipe, read, ya action buttons tap kar sakte hain."
            lower.contains("error") ->
                "JARVIS Diagnostic: Screen par dikhayi dene wala error network timeout ya missing permission se related lagta hai. Kripya Retry button tap karein ya settings me permissions check karein."
            lower.contains("kya karna hai") ->
                "JARVIS Guide: Is page par aage badhne ke liye primary action button (jaise Continue, Submit, ya Next) tap karein. Agar form hai toh zaroori fields bharein."
            else ->
                "JARVIS Screen Analysis: Screen snapshot process ho gaya hai. Aapke sawaal (\"$query\") ke anusaar, is page par moujood sabhi main elements active hain."
        }
        return AiServiceResult.Success(text)
    }

    /**
     * Fallback on-device intelligent responses for Hindi/Hinglish/English when offline or Firebase AI is not yet provisioned.
     */
    private fun fallbackLocalResponse(input: String): AiServiceResult {
        val lower = input.lowercase()
        val response = when {
            lower.contains("tum kaun ho") || lower.contains("who are you") || lower.contains("kya ho tum") ->
                "Main JARVIS hoon—aapka personal AI assistant! Main Hindi, Hinglish, aur English samajh sakta hoon. Main phone me apps open kar sakta hoon, YouTube par gaana khoj sakta hoon, WhatsApp messages draft kar sakta hoon, aur aapke sawaalon ke jawaab de sakta hoon."

            lower.contains("kya kar sakte ho") || lower.contains("what can you do") || lower.contains("madad") || lower.contains("help") ->
                "Aap mujhse ye sab pooch ya karwa sakte hain:\n" +
                        "1. Apps open karna: 'YouTube kholo', 'WhatsApp kholo', 'Camera kholo', 'Chrome kholo'\n" +
                        "2. Music/Video: 'YouTube par Arijit Singh ka gaana chalao', 'Kesariya search karo'\n" +
                        "3. Messaging: 'WhatsApp par message bhejne ke liye taiyar karo'\n" +
                        "4. Voice: Voice Studio me meri aawaz badal sakte hain\n" +
                        "5. Image: Image Generator screen par tasveer describe kar sakte hain."

            lower.contains("namaste") || lower.contains("hello") || lower.contains("hi") || lower.contains("kya haal") ->
                "Namaste! Main badhiya hoon. Batiye aaj main aapki kya madad kar sakta hoon? Aap mic tap karke bol sakte hain ya type kar sakte hain."

            lower.contains("dhanyawad") || lower.contains("thank") || lower.contains("shukriya") ->
                "Aapka swagat hai! Main hamesha aapki seva me hazir hoon."

            else ->
                "Maine aapka sandesh samajh liya: \"$input\". Main aapke phone ke vibhinn actions execute karne aur baat karne ke liye taiyar hoon. Agar aap kisi feature ko trigger karna chahte hain toh jaise 'YouTube kholo' ya 'gaana chalao' bolein."
        }
        return AiServiceResult.Success(response)
    }
}
